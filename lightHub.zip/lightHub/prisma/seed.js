const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function seed() {
  try {
    // Clean up existing data
    await prisma.analytics.deleteMany();
    await prisma.billingHistory.deleteMany();
    await prisma.task.deleteMany();
    await prisma.automation.deleteMany();
    await prisma.session.deleteMany();
    await prisma.user.deleteMany();

    // Create demo users
    const hashedPassword = await bcrypt.hash('password', 10);

    const demoUser = await prisma.user.create({
      data: {
        email: 'demo@example.com',
        name: 'Demo User',
        password: hashedPassword,
        plan: 'PRO',
        subscriptionStatus: 'active',
        usageCount: 45,
        taskCreatedCount: 12,
      },
    });

    const freeUser = await prisma.user.create({
      data: {
        email: 'free@example.com',
        name: 'Free User',
        password: hashedPassword,
        plan: 'FREE',
        usageCount: 18,
        taskCreatedCount: 8,
      },
    });

    const businessUser = await prisma.user.create({
      data: {
        email: 'business@example.com',
        name: 'Business User',
        password: hashedPassword,
        plan: 'BUSINESS',
        subscriptionStatus: 'active',
        usageCount: 200,
        taskCreatedCount: 50,
      },
    });

    // Create sample tasks
    await prisma.task.createMany({
      data: [
        {
          userId: demoUser.id,
          title: 'Review project proposal',
          description: 'Review and provide feedback on the Q1 project proposal',
          status: 'completed',
          priority: 'high',
          dueDate: new Date(new Date().setDate(new Date().getDate() - 2)),
        },
        {
          userId: demoUser.id,
          title: 'Prepare presentation',
          description: 'Prepare slides for the team meeting',
          status: 'in-progress',
          priority: 'high',
          dueDate: new Date(new Date().setDate(new Date().getDate() + 1)),
        },
        {
          userId: demoUser.id,
          title: 'Update documentation',
          description: 'Update API documentation for new endpoints',
          status: 'pending',
          priority: 'medium',
          dueDate: new Date(new Date().setDate(new Date().getDate() + 5)),
        },
        {
          userId: freeUser.id,
          title: 'Grocery shopping',
          status: 'pending',
          priority: 'low',
        },
        {
          userId: businessUser.id,
          title: 'Team standup',
          description: 'Daily team synchronization meeting',
          status: 'completed',
          priority: 'medium',
        },
      ],
    });

    // Create sample automations
    await prisma.automation.createMany({
      data: [
        {
          userId: demoUser.id,
          name: 'Task completion notification',
          description: 'Send email when task is completed',
          trigger: 'task_completed',
          action: 'send_email',
          isEnabled: true,
        },
        {
          userId: demoUser.id,
          name: 'Weekly summary',
          description: 'Send weekly productivity summary',
          trigger: 'time_based',
          action: 'send_email',
          isEnabled: true,
        },
        {
          userId: businessUser.id,
          name: 'Team notification',
          description: 'Notify team when task is assigned',
          trigger: 'task_created',
          action: 'send_email',
          isEnabled: true,
        },
      ],
    });

    // Create analytics
    const today = new Date();
    await prisma.analytics.createMany({
      data: [
        {
          userId: demoUser.id,
          date: today,
          tasksCreated: 3,
          tasksCompleted: 2,
          aiRequests: 15,
          automationsTriggered: 2,
          focusTime: 120,
        },
        {
          userId: demoUser.id,
          date: new Date(today.setDate(today.getDate() - 5)),
          tasksCreated: 5,
          tasksCompleted: 4,
          aiRequests: 20,
          automationsTriggered: 3,
          focusTime: 180,
        },
      ],
    });

    console.log('✅ Database seeded successfully!');
    console.log('\n📝 Demo Credentials:');
    console.log('  Email: demo@example.com');
    console.log('  Password: password');
    console.log('  Plan: Pro');
    console.log('\n🆓 Free Plan Demo:');
    console.log('  Email: free@example.com');
    console.log('  Password: password');
    console.log('\n💼 Business Plan Demo:');
    console.log('  Email: business@example.com');
    console.log('  Password: password');
  } catch (error) {
    console.error('Error seeding database:', error);
    process.exit(1);
  } finally {
    await prisma.$disconnect();
  }
}

seed();
