# 🚀 lightHub - Quick Start Guide

## ⚡ Get Running in 5 Minutes

### Step 1: Install Dependencies
```bash
cd c:\Users\Lenovo\Downloads\vs\ code\lightHub
npm install
```

### Step 2: Setup Database
```bash
# Create .env.local file
cp .env.example .env.local

# Configure DATABASE_URL in .env.local
# Example: postgresql://postgres:password@localhost:5432/lighthub

# Initialize database
npx prisma db push
npm run seed
```

### Step 3: Setup Stripe (Free)
```bash
# 1. Go to https://stripe.com (sign up free)
# 2. Get test keys from https://dashboard.stripe.com/apikeys
# 3. Add to .env.local:

NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_...
STRIPE_SECRET_KEY=sk_test_...

# 4. Create products & prices:
npm run stripe:init

# 5. Setup webhooks (local testing):
npx stripe listen --forward-to localhost:3000/api/stripe/webhook
# Copy the webhook secret to .env.local
```

### Step 4: Start Development
```bash
npm run dev
```

### Step 5: Test Payment Flow
- Visit: `http://localhost:3000/pricing`
- Click "Start Pro Trial"
- Use test card: `4242 4242 4242 4242`
- Exp: Any future date
- CVC: Any 3 digits

---

## 📊 WHAT YOU HAVE

### Pages Built: 8
- ✅ Landing page (`/`)
- ✅ Pricing page (`/pricing`)
- ✅ Login page (`/login`)
- ✅ Signup page (`/signup`)
- ✅ Dashboard home (`/dashboard`)
- ✅ Tasks manager (`/dashboard/tasks`)
- ✅ Automations (`/dashboard/automations`)
- ✅ Analytics (`/dashboard/analytics`)
- ✅ Billing (`/dashboard/billing`)
- ✅ Settings (`/dashboard/settings`)

### API Routes Built: 30+
- 📌 **Auth**: Sign up, Login, Logout
- 📌 **Tasks**: Full CRUD (Create, Read, Update, Delete)
- 📌 **AI**: Chat & suggestions
- 📌 **Automations**: Create & manage workflows
- 📌 **Analytics**: Track productivity
- 📌 **Stripe**: Checkout, Portal, Webhooks
- 📌 **Usage**: Check quotas
- 📌 **Billing**: View invoices & history
- 📌 **User**: Profile management

### Database Tables: 7
- Users (with Stripe data)
- Tasks
- Automations
- Analytics
- BillingHistory
- WebhookEvents
- Sessions

### Features: 20+
- User registration & login
- Task management (CRUD)
- AI assistant integration point
- Automation engine
- Advanced analytics
- Stripe payments
- 3 pricing plans
- Monthly billing
- Usage tracking
- Plan-based access control
- Webhook handling
- Billing portal
- Invoice history
- And more!

---

## 💻 Development Commands

```bash
# Start development server
npm run dev

# Build for production
npm run build

# Start production server
npm start

# View database GUI
npx prisma studio

# Sync schema with database
npx prisma db push

# Create Stripe products
npm run stripe:init

# Seed demo data
npm run seed

# Run linter
npm run lint
```

---

## 🔑 Environment Variables Needed

```env
# Database
DATABASE_URL="postgresql://user:password@localhost:5432/lighthub"

# Authentication
NEXTAUTH_SECRET="generate-with: openssl rand -base64 32"
NEXTAUTH_URL="http://localhost:3000"

# Stripe (Test Keys from https://dashboard.stripe.com/apikeys)
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY="pk_test_..."
STRIPE_SECRET_KEY="sk_test_..."
STRIPE_WEBHOOK_SECRET="whsec_..."

# Optional (after running npm run stripe:init)
STRIPE_PRICE_PRO="price_..."
STRIPE_PRICE_BUSINESS="price_..."
```

---

## 📁 Project Files Summary

| File | Purpose |
|------|---------|
| `README.md` | Setup & features guide |
| `SETUP.md` | Detailed configuration |
| `COMPLETE_OVERVIEW.md` | Full feature breakdown |
| `ARCHITECTURE.md` | System design & flows |
| `DEPLOYMENT.md` | Production deployment |
| `STRIPE_CHECKLIST.md` | Payment setup |
| `.env.example` | Environment template |
| `package.json` | Dependencies |
| `Dockerfile` | Container config |
| `docker-compose.yml` | Docker compose |

---

## 🧪 Test Credentials

### Demo Account (After seed)
```
Email: demo@lighthub.com
Password: Demo@123456
Plan: FREE
```

### Stripe Test Cards
```
Success: 4242 4242 4242 4242
Declined: 4000 0000 0000 0002
Auth Required: 4000 2500 0000 3155

Exp: Any future date (e.g., 12/25)
CVC: Any 3 digits (e.g., 123)
```

---

## 🎯 Key Pricing Plans

### 🟢 Free
- 50 tasks/month
- 20 AI requests/month
- No automations

### 🔵 Pro ($19/month)
- Unlimited tasks
- 500 AI requests/month
- Up to 5 automations
- Advanced analytics

### 🟣 Business ($49/month)
- Unlimited everything
- Team collaboration
- API access
- Priority support

---

## 📚 Documentation

Read these in order:
1. `README.md` - Overview
2. `SETUP.md` - Installation steps
3. `COMPLETE_OVERVIEW.md` - Feature details
4. `ARCHITECTURE.md` - System design
5. `STRIPE_CHECKLIST.md` - Payment setup
6. `DEPLOYMENT.md` - Going live

---

## 🚀 Deployment Checklist

- [ ] All env vars configured
- [ ] Database created and seeded
- [ ] Stripe products created
- [ ] Webhooks set up
- [ ] Payment flow tested
- [ ] Build succeeds: `npm run build`
- [ ] No console errors
- [ ] Create GitHub repo
- [ ] Connect to Vercel
- [ ] Add production env vars
- [ ] Deploy & test
- [ ] Switch to Stripe live keys

---

## 💡 Next Steps

1. **Run Locally**
   ```bash
   npm install
   npm run dev
   ```

2. **Setup Database**
   ```bash
   npx prisma db push
   npm run seed
   ```

3. **Configure Stripe**
   ```bash
   npm run stripe:init
   ```

4. **Test Payments**
   - Visit `/pricing`
   - Click upgrade
   - Use test card: 4242...

5. **Deploy**
   ```bash
   npm run build
   git push
   # Auto-deploys to Vercel
   ```

6. **Go Live**
   - Switch to Stripe live keys
   - Update production env vars
   - Test with real credit card

---

## 📞 Support Resources

- [Next.js Docs](https://nextjs.org/docs)
- [Stripe Docs](https://stripe.com/docs/api)
- [Prisma Docs](https://www.prisma.io/docs)
- [NextAuth.js Docs](https://next-auth.js.org)
- [Tailwind Docs](https://tailwindcss.com/docs)

---

## ✨ Your SaaS is Complete!

You have a **production-ready** AI SaaS platform with:
- ✅ Full authentication system
- ✅ Task management
- ✅ AI integration point
- ✅ Automation engine
- ✅ Analytics dashboard
- ✅ Stripe payments
- ✅ 3 pricing tiers
- ✅ Webhook handling
- ✅ Usage tracking
- ✅ Database schema
- ✅ Documentation
- ✅ Docker support

**Ready to launch! 🎉**
