# lightHub - Complete Setup Guide

Welcome to lightHub! This guide will walk you through setting up a production-ready SaaS platform with Stripe integration.

## ⏱️ Setup Time: ~30 minutes

## 📋 Prerequisites Check

Before starting, ensure you have:
- [ ] Node.js 18+ installed (`node --version`)
- [ ] Git installed (`git --version`)
- [ ] A Stripe account (free at https://stripe.com)
- [ ] A PostgreSQL database (local or cloud)
- [ ] A code editor (VS Code recommended)

## 🚀 Step-by-Step Setup

### Step 1: Clone & Install (5 min)

```bash
# Clone the repository
git clone <your-repo-url>
cd lighthub

# Install dependencies
npm install
```

### Step 2: Create Environment File (2 min)

Copy the template and add your credentials:

```bash
cp .env.example .env.local
```

Now edit `.env.local` with your values:

```env
# Database Connection
DATABASE_URL="postgresql://user:password@localhost:5432/lighthub"

# Generate this with: openssl rand -base64 32
NEXTAUTH_SECRET="your-generated-secret-here"

# Your domain (http://localhost:3000 for local development)
NEXTAUTH_URL="http://localhost:3000"

# Stripe Keys (from https://dashboard.stripe.com/apikeys)
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY="pk_test_..."
STRIPE_SECRET_KEY="sk_test_..."
STRIPE_WEBHOOK_SECRET="whsec_..." # Will set up webhook later

# Stripe Price IDs (will get from Stripe products page)
STRIPE_PRICE_PRO="price_..."
STRIPE_PRICE_BUSINESS="price_..."
```

### Step 3: Database Setup (5 min)

#### Option A: Local PostgreSQL (Recommended for development)

If you don't have PostgreSQL installed, use Docker:

```bash
docker run -d \
  --name lighthub-postgres \
  -e POSTGRES_DB=lighthub \
  -e POSTGRES_PASSWORD=password \
  -p 5432:5432 \
  postgres:15-alpine
```

Update your `.env.local`:
```env
DATABASE_URL="postgresql://postgres:password@localhost:5432/lighthub"
```

#### Option B: Cloud Database (Neon, Supabase, etc.)

Get your connection string from your cloud provider and add it to `.env.local`.

#### Option C: Docker Compose (Full setup)

```bash
docker-compose up -d
```

This starts both PostgreSQL and the app.

### Step 4: Generate Stripe Secrets (3 min)

Generate the NEXTAUTH_SECRET:

```bash
openssl rand -base64 32
```

Copy the output and add it to `.env.local`:
```env
NEXTAUTH_SECRET="<paste-here>"
```

### Step 5: Create Stripe Products (10 min)

1. **Go to Stripe Dashboard**: https://dashboard.stripe.com/products

2. **Create Pro Plan Product**:
   - Click "Add Product"
   - Name: "Pro Plan"
   - Type: Service
   - Description: "Professional plan with 500 AI requests"
   - Pricing:
     - Select "Standard pricing"
     - Amount: 1999 (for $19.99)
     - Currency: USD
     - Billing Period: Monthly
   - Click "Add Product"
   - Copy the **Price ID** (looks like `price_1234567890`)

3. **Create Business Plan Product**:
   - Repeat above with:
     - Name: "Business Plan"
     - Amount: 4999 (for $49.99)
   - Copy the **Price ID**

4. **Add to .env.local**:
   ```env
   STRIPE_PRICE_PRO="price_xxxxx"
   STRIPE_PRICE_BUSINESS="price_xxxxx"
   ```

### Step 6: Run Database Migrations (3 min)

```bash
# Create database tables
npx prisma migrate dev

# Seed with demo data (optional)
npm run seed
```

Check that everything works:

```bash
npx prisma studio
```

This opens a UI showing your database. You should see:
- Users table (with demo users)
- Task table
- Other tables for subscriptions, etc.

Close with `Ctrl+C`.

### Step 7: Start Development Server (2 min)

```bash
npm run dev
```

The app is now running at **http://localhost:3000** 🎉

### Step 8: Test the Application (3 min)

1. **Sign Up**: Go to http://localhost:3000 → "Get Started"
   - Create an account with any email
   - You'll be on the FREE plan

2. **View Dashboard**: Login and explore:
   - Create tasks
   - View your plan
   - Check billing page

3. **Test Stripe Checkout** (next step with webhook):
   - Click "Upgrade to Pro"
   - You'll be redirected to Stripe Checkout
   - Use test card: `4242 4242 4242 4242`
   - Any future expiry date
   - Any CVC
   - Click "Pay"

### Step 9: Setup Stripe Webhook (5 min)

The webhook allows Stripe to tell your app about payment events.

#### Using Stripe CLI (Recommended for local development)

1. **Download Stripe CLI**: https://stripe.com/docs/stripe-cli

2. **Login to Stripe**:
   ```bash
   stripe login
   ```

3. **Start webhook forwarding**:
   ```bash
   stripe listen --forward-to localhost:3000/api/stripe/webhook
   ```

   You'll see:
   ```
   Webhook signing secret for whsec_...
   ```

4. **Copy the secret** and add to `.env.local`:
   ```env
   STRIPE_WEBHOOK_SECRET="whsec_..."
   ```

5. **Restart your app** (`npm run dev`)

Now webhooks are flowing from Stripe to your local app!

#### For Production (Without Stripe CLI)

1. Go to https://dashboard.stripe.com/webhooks
2. Click "Add an endpoint"
3. Endpoint URL: `https://yourdomain.com/api/stripe/webhook`
4. Select events:
   - ✓ checkout.session.completed
   - ✓ invoice.payment_succeeded
   - ✓ invoice.payment_failed
   - ✓ customer.subscription.deleted
   - ✓ customer.subscription.updated
5. Click "Add endpoint"
6. Copy signing secret to `STRIPE_WEBHOOK_SECRET`

### Step 10: Full Test Flow (10 min)

Now test the complete payment flow:

1. **Create new account** (or use demo@example.com)
2. **Go to Billing**
3. **Click "Upgrade to Pro"**
4. **Complete checkout**:
   - Card: `4242 4242 4242 4242`
   - Date: `12/25`
   - CVC: `123`
5. **Verify**:
   - You should be redirected to dashboard
   - Your plan should show "Pro"
   - Check Stripe webhook logs for success

## ✨ After Setup

### Demo Credentials (if you seeded data)

```
Email: demo@example.com
Password: password
Plan: Pro
```

### Next Steps

1. **Customize branding**: Edit `src/app/page.tsx` (landing page) colors
2. **Add features**: Implement AI assistant, automations, etc.
3. **Test more**: Try upgrading between plans
4. **Deploy**: Follow [DEPLOYMENT.md](DEPLOYMENT.md) guide

## 🧪 Testing Scenarios

### Test Free Plan Limit
1. Sign up with free account
2. Create 50 tasks (limit for free plan)
3. Try creating 51st → Should be blocked
4. See upgrade prompt

### Test Plan Downgrade
1. Login with Pro account
2. Go to Billing → Manage Billing (Stripe portal)
3. Cancel subscription
4. After billing period, plan reverts to Free

### Test Webhook Events
With Stripe CLI running:

```bash
# Simulate payment succeeded
stripe trigger invoice.payment_succeeded

# Check your database for billing history
npx prisma studio
```

## 🐛 Troubleshooting

### "Cannot connect to database"
```bash
# Check connection string
echo $DATABASE_URL

# Test connection
psql $DATABASE_URL -c "SELECT 1"

# If using Docker, make sure it's running
docker ps | grep postgres
```

### "Stripe key is missing"
1. Check `.env.local` has all keys
2. Keys should NOT have quotes around them
3. Restart dev server after changing `.env.local`

### "Webhook signature verification failed"
1. Is Stripe CLI running? (`stripe listen...`)
2. Did you copy the webhook secret correctly?
3. Check you're using NEXT_AUTH_URL that matches

### "Can't create checkout session"
1. Did you set STRIPE_PRICE_PRO and STRIPE_PRICE_BUSINESS?
2. Are the price IDs valid? (from Stripe dashboard)
3. Check browser console for API errors

### "Can't log in"
1. Did you run `npx prisma migrate dev`?
2. Check password is hashed (next-auth should handle this)
3. Try creating a new account instead

## 📚 Key Files to Know

| File | Purpose |
|------|---------|
| `.env.local` | Your secrets & configuration |
| `src/lib/stripe.ts` | Stripe utilities & products |
| `src/lib/webhook-handler.ts` | Handles Stripe events |
| `src/app/api/stripe/*` | Stripe API endpoints |
| `prisma/schema.prisma` | Database structure |
| `src/app/dashboard/billing/page.tsx` | Billing page UI |

## 🔐 Security Reminders

- Never commit `.env.local` (it's in `.gitignore`)
- Never share your `STRIPE_SECRET_KEY`
- Only use test keys for development
- Use production keys when deploying

## 📞 Need Help?

1. Check logs: `npm run dev` shows errors
2. Read error messages carefully
3. Check Stripe dashboard for webhook failures
4. Visit: https://stripe.com/docs/errors
5. Community: https://github.com/issues

## 🎯 What's Next?

After setup is complete:

1. **Customize**: Edit colors, copy, features
2. **Add Team Features**: Implement for Business plan
3. **Setup Analytics**: Integrate analytics service
4. **Add AI**: Integrate OpenAI or similar
5. **Deploy**: Use [DEPLOYMENT.md](DEPLOYMENT.md)

---

## ⚡ Quick Command Reference

```bash
# Development
npm run dev                 # Start dev server
npx prisma studio         # Open database UI
npm run seed               # Load demo data
stripe listen --forward-to localhost:3000/api/stripe/webhook  # Webhook local

# Database
npx prisma migrate dev     # Run migrations
npx prisma db push         # Push schema to DB
npx prisma generate        # Generate Prisma client

# Production
npm run build              # Build for production
npm start                  # Start production server
docker-compose up          # Run with Docker

# Cleanup
rm -rf node_modules        # Clear dependencies
npm install                # Reinstall
docker stop lighthub-*     # Stop Docker containers
```

---

## ✅ Setup Checklist

Before you start building:

- [ ] Node.js 18+ installed
- [ ] Dependencies installed (`npm install`)
- [ ] `.env.local` created with all keys
- [ ] PostgreSQL running
- [ ] Database migrations done (`npx prisma migrate dev`)
- [ ] Stripe products created (Pro & Business)
- [ ] Stripe keys added to `.env.local`
- [ ] Stripe CLI webhook running
- [ ] Dev server running (`npm run dev`)
- [ ] Can signup and login
- [ ] Can see dashboard
- [ ] Can start checkout flow
- [ ] Webhook receiving events

Once all checked, you're ready to build! 🚀

---

Good luck with lightHub! Feel free to customize and extend it for your needs.
