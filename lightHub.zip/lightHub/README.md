# lightHub - Production-Ready AI SaaS Platform

A complete, fully functional AI-powered SaaS productivity application with integrated Stripe payment system, task management, AI assistance, automation engine, and advanced analytics.

## 🚀 Features

### ✅ Core Functionality
- **Smart Task Management** - Create, organize, and prioritize tasks with AI insights
- **AI Assistant** - Powered by OpenAI integration for smart suggestions
- **Automation Engine** - Create powerful automations to save time
- **Advanced Analytics** - Track productivity metrics and insights
- **User Authentication** - Secure NextAuth.js integration

### 💳 Stripe Payment Integration
- **3 Pricing Tiers** - Free, Pro ($19/month), Business ($49/month)
- **Checkout Flow** - Seamless Stripe Checkout integration
- **Billing Portal** - Customer-managed subscriptions
- **Webhook Handling** - Real-time payment event processing
- **Usage Tracking** - Automatic monthly quota resets
- **Advanced Analytics**: Track productivity metrics and performance trends

### 💳 Payment System
- **Stripe Integration**: Full subscription management with Stripe
- **3 Pricing Tiers**:
  - 🟢 **Free**: Limited features (50 tasks/month, 20 AI requests)
  - 🔵 **Pro**: $19/month (Unlimited tasks, 500 AI requests)
  - 🟣 **Business**: $49/month (Unlimited everything + Team features)
- **Webhook Handling**: Real-time subscription updates
- **Billing Portal**: Customer-friendly subscription management
- **Usage Tracking**: Monitor and enforce plan limits

### 🔐 Security
- NextAuth.js authentication
- Bcrypt password hashing
- Server-side plan validation
- Stripe signature verification
- Protected API routes with middleware

## 📦 Tech Stack

- **Frontend**: Next.js 14, React 18, TypeScript, Tailwind CSS
- **Backend**: Next.js API routes, Node.js
- **Database**: PostgreSQL with Prisma ORM
- **Authentication**: NextAuth.js
- **Payments**: Stripe
- **UI Components**: Custom + Lucide Icons
- **Forms**: React Hook Form, Zod validation
- **Toast Notifications**: React Hot Toast

## 🛠️ Getting Started

### Prerequisites
- Node.js 18+
- PostgreSQL database
- Stripe account
- Git

### 1. Clone & Install

```bash
git clone <repository-url>
cd lighthub
npm install
```

### 2. Environment Setup

Copy `.env.example` to `.env.local` and fill in your values:

```bash
cp .env.example .env.local
```

**Required Variables:**

```env
# Database
DATABASE_URL="postgresql://user:password@localhost:5432/lighthub"

# NextAuth
NEXTAUTH_SECRET="generate-with: openssl rand -base64 32"
NEXTAUTH_URL="http://localhost:3000"

# Stripe Keys (from https://dashboard.stripe.com/apikeys)
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY="pk_test_..."
STRIPE_SECRET_KEY="sk_test_..."
STRIPE_WEBHOOK_SECRET="whsec_..." # From webhook settings
```

### 3. Database Setup

```bash
# Run migrations
npx prisma migrate dev

# (Optional) Seed demo data
npm run seed
```

### 4. Stripe Configuration

#### A. Create Products & Prices

Navigate to https://dashboard.stripe.com/products and:

1. **Create Product "Pro"**
   - Price: $19.99/month
   - Save the Price ID

2. **Create Product "Business"**
   - Price: $49.99/month
   - Save the Price ID

Add to `.env.local`:
```env
STRIPE_PRICE_PRO="price_xxxxx"
STRIPE_PRICE_BUSINESS="price_xxxxx"
```

#### B. Set Up Webhook

1. Go to https://dashboard.stripe.com/webhooks
2. Click "Add an endpoint"
3. **URL**: `https://yourdomain.com/api/stripe/webhook`
4. **Events**:
   - `checkout.session.completed`
   - `invoice.payment_succeeded`
   - `invoice.payment_failed`
   - `customer.subscription.deleted`
   - `customer.subscription.updated`
5. Copy the webhook signing secret to `STRIPE_WEBHOOK_SECRET`

### 5. Run Development Server

```bash
npm run dev
```

Open http://localhost:3000 in your browser.

## 🧪 Testing Stripe Integration Locally

### With Stripe CLI

```bash
# Install Stripe CLI from https://stripe.com/docs/stripe-cli

# Login to Stripe
stripe login

# Forward webhooks to localhost
stripe listen --forward-to localhost:3000/api/stripe/webhook

# You'll get a signing secret, add it to .env.local
```

### Test Payment Flow

Use Stripe test card: `4242 4242 4242 4242`
- Expiry: Any future date
- CVC: Any 3 digits

## 📁 Project Structure

```
src/
├── app/                    # Next.js App Router
│   ├── api/               # API Routes
│   │   ├── auth/          # Authentication
│   │   ├── stripe/        # Payment endpoints
│   │   ├── tasks/         # Task management
│   │   └── user/          # User management
│   ├── dashboard/         # Protected dashboard
│   ├── (public)/          # Public pages
│   └── layout.tsx         # Root layout
├── components/
│   ├── ui/                # Reusable UI components
│   └── dashboard/         # Dashboard components
├── lib/
│   ├── auth.ts            # NextAuth configuration
│   ├── stripe.ts          # Stripe utilities
│   ├── db.ts              # Prisma client
│   ├── middleware.ts      # Auth & plan middleware
│   ├── webhook-handler.ts # Stripe webhook logic
│   └── usage.ts           # Usage tracking
└── prisma/
    └── schema.prisma      # Database schema
```

## 📊 Database Schema

### Core Tables

- **Users**: User accounts with subscription data
- **Sessions**: NextAuth session management
- **Task**: User tasks with AI summaries
- **Automation**: Automated workflows
- **Analytics**: User productivity metrics
- **BillingHistory**: Invoice records
- **WebhookEvent**: Stripe webhook tracking

See `prisma/schema.prisma` for full schema.

## 🔌 API Routes

### Authentication
- `POST /api/auth/signup` - Create account
- `POST /api/auth/[...nextauth]` - NextAuth handler
- `POST /api/auth/signin` - Sign in (via NextAuth)

### Stripe Payment
- `POST /api/stripe/create-checkout` - Start checkout
- `POST /api/stripe/create-portal` - Billing portal
- `POST /api/stripe/webhook` - Webhook handler

### Tasks
- `GET /api/tasks` - List user tasks
- `POST /api/tasks` - Create task (checks usage)
- `PATCH /api/tasks/[id]` - Update task
- `DELETE /api/tasks/[id]` - Delete task

### Usage & Plan
- `GET /api/usage/check?feature=aiRequests` - Check usage limit
- `POST /api/usage/check` - POST version

### User
- `GET /api/user` - Get user profile
- `PATCH /api/user` - Update profile

## 🚀 Deployment

### Vercel (Recommended)

```bash
# Connect your GitHub repo to Vercel
# Add environment variables in Vercel dashboard

# Deploy
vercel deploy --prod
```

### Docker

```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build
EXPOSE 3000
CMD ["npm", "start"]
```

### Environment Variables for Production

Update your hosting provider with:
- `DATABASE_URL` (PostgreSQL connection string)
- `NEXTAUTH_SECRET` (generate new one)
- `NEXTAUTH_URL` (your production domain)
- Stripe keys (production keys from Live mode)
- All other `.env.local` variables

## 💰 Pricing Tiers Details

### Free Plan
- Tasks: 50/month limit
- AI Requests: 20/month
- Features: Basic dashboard
- Watermark on exports

### Pro Plan ($19/month)
- Tasks: Unlimited
- AI Requests: 500/month
- Features: Automations, Focus mode, Analytics, Priority support

### Business Plan ($49/month)
- Everything unlimited
- Team collaboration
- Shared projects
- Admin dashboard
- Advanced analytics
- API access
- 24/7 Priority support

## 🔄 Usage Tracking

The system automatically:
1. Tracks feature usage per user
2. Resets monthly on billing cycle
3. Prevents feature access when limits exceeded
4. Shows usage progress in dashboard

Override in `src/lib/usage.ts`:

```typescript
export const USAGE_LIMITS = {
  [Plan.FREE]: {
    aiRequests: 20,
    tasksPerMonth: 50,
  },
  // ... other plans
};
```

## 🧾 Webhook Events Handled

1. **checkout.session.completed**: Activate subscription
2. **invoice.payment_succeeded**: Update billing history
3. **invoice.payment_failed**: Mark subscription past due
4. **customer.subscription.updated**: Sync plan changes
5. **customer.subscription.deleted**: Cancel subscription

## 🔒 Security Checklist

- ✅ Stripe webhook signature verification
- ✅ Server-side plan validation
- ✅ JWT tokens with NextAuth
- ✅ Bcrypt password hashing
- ✅ Protected API routes
- ✅ CORS configuration
- ✅ SQL injection prevention (Prisma)
- ✅ Rate limiting (add if needed)

## 📈 Monitoring & Logging

Current setup logs to:
- Console (development)
- Stripe dashboard (payments)
- PostgreSQL (data)

For production, integrate:
- Sentry (error tracking)
- LogRocket (session replay)
- Stripe events monitoring

## 🤝 Contributing

1. Create a feature branch
2. Make your changes
3. Submit a pull request

## 📝 License

MIT License - see LICENSE file

## 🆘 Support

For issues and questions:
- GitHub Issues
- Email: support@lighthub.io
- Stripe Support: https://support.stripe.com

## 🎯 Future Roadmap

- [ ] AI-powered task suggestions
- [ ] Team collaboration features
- [ ] Advanced automation builder
- [ ] Email integrations
- [ ] Mobile app (React Native)
- [ ] Zapier integration
- [ ] More payment methods (Razorpay, PayPal)
- [ ] One-time lifetime payment
- [ ] Referral program
- [ ] Affiliate system

---

## Quick Start Summary

```bash
# 1. Clone & install
git clone <repo> && cd lighthub && npm install

# 2. Setup environment
cp .env.example .env.local
# Edit .env.local with your values

# 3. Setup database
npx prisma migrate dev

# 4. Get Stripe keys from dashboard
# Add STRIPE_PRICE_PRO and STRIPE_PRICE_BUSINESS

# 5. Run dev server
npm run dev

# 6. Visit http://localhost:3000
```

That's it! You have a fully functional SaaS platform.
