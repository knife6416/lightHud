#!/usr/bin/env node

/**
 * Stripe Products & Prices Initialization Script
 * Run this to create Stripe products and prices for lightHub pricing tiers
 * 
 * Usage: npm run stripe:init
 */

require('dotenv').config({ path: '.env.local' });

const Stripe = require('stripe');

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: '2023-10-16',
});

const PLANS = {
  pro: {
    name: 'Pro Plan',
    description: 'Best for professionals & teams',
    price: 1999, // $19.99 in cents
  },
  business: {
    name: 'Business Plan',
    description: 'For growing teams & enterprises',
    price: 4999, // $49.99 in cents
  },
};

async function createProducts() {
  console.log('🚀 Initializing Stripe Products & Prices...\n');

  if (!process.env.STRIPE_SECRET_KEY) {
    console.error('❌ Error: STRIPE_SECRET_KEY is not set in .env.local');
    process.exit(1);
  }

  try {
    // Create products and prices
    const priceIds = {};

    for (const [planKey, planData] of Object.entries(PLANS)) {
      console.log(`📦 Creating ${planKey} product...`);

      // Create product
      const product = await stripe.products.create({
        name: planData.name,
        description: planData.description,
        metadata: {
          plan: planKey,
        },
      });

      console.log(`✅ Product created: ${product.id}`);

      // Create price
      const price = await stripe.prices.create({
        product: product.id,
        unit_amount: planData.price,
        currency: 'usd',
        recurring: {
          interval: 'month',
          usage_type: 'licensed',
        },
        metadata: {
          plan: planKey,
        },
      });

      console.log(`✅ Price created: ${price.id}\n`);

      priceIds[planKey] = price.id;
    }

    // Output environment variables
    console.log('\n📋 Add these to your .env.local:\n');
    console.log('# Stripe Price IDs');
    console.log(`STRIPE_PRICE_PRO="${priceIds.pro}"`);
    console.log(`STRIPE_PRICE_BUSINESS="${priceIds.business}"`);

    console.log('\n✨ Stripe setup complete!');
    console.log('👉 Next steps:');
    console.log('   1. Copy the price IDs above to your .env.local');
    console.log('   2. Set up webhooks: https://dashboard.stripe.com/webhooks');
    console.log('   3. For local testing: stripe listen --forward-to localhost:3000/api/stripe/webhook');

  } catch (error) {
    console.error('❌ Error:', error.message);
    process.exit(1);
  }
}

createProducts();
