# lightHub - System Architecture & Payment Flow

## 🏗️ SYSTEM ARCHITECTURE

```
┌─────────────────────────────────────────────────────────────────────┐
│                         Frontend Layer (Next.js)                    │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  Landing Page  →  Pricing Page  →  Login/Signup  →  Dashboard    │
│      (/)            (/pricing)      (/login)         (/dashboard)  │
│                                                                     │
│  ┌──────────────┐  ┌─────────────┐  ┌──────────────────────┐      │
│  │ PricingCard  │  │ Form        │  │ Dashboard Client     │      │
│  │ Component    │  │ Components  │  │ ├─ Sidebar           │      │
│  └──────────────┘  └─────────────┘  │ ├─ TopNav            │      │
│                                      │ ├─ Tasks             │      │
│                                      │ ├─ Automations       │      │
│                                      │ ├─ Analytics         │      │
│                                      │ ├─ Billing           │      │
│                                      │ └─ Settings          │      │
│                                      └──────────────────────┘      │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
                              ↓↓↓
┌─────────────────────────────────────────────────────────────────────┐
│                    API Layer (Next.js Routes)                       │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  📌 Auth          📌 Tasks         📌 AI            📌 Payments    │
│  ├─ Signup        ├─ GET /tasks    ├─ POST /chat    ├─ Checkout   │
│  ├─ Login         ├─ POST /tasks   └─ Response      ├─ Portal     │
│  └─ Session       ├─ Patch /[id]                    ├─ Webhook    │
│                   └─ DELETE /[id]  📌 Analytics     └─ Status     │
│  📌 Automations                    ├─ GET           📌 Billing    │
│  ├─ GET /auto                      ├─ POST          ├─ History    │
│  ├─ POST /auto                     └─ Summary       └─ Invoices   │
│  ├─ PATCH /[id]                                                   │
│  └─ DELETE /[id]  📌 Usage                                         │
│                   ├─ Check Usage                                   │
│                   └─ Quota Logic                                   │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
                              ↓↓↓
┌─────────────────────────────────────────────────────────────────────┐
│                   Services & Business Logic Layer                   │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ┌─────────────────┐  ┌──────────────────┐  ┌─────────────────┐   │
│  │ Auth Service    │  │ Stripe Service   │  │ Usage Service   │   │
│  ├─ Hash Password  │  ├─ Create Session  │  ├─ Check Quotas   │   │
│  ├─ Verify JWT     │  ├─ Handle Webhook │  ├─ Reset Monthly  │   │
│  └─ Manage Session │  └─ Manage Plans   │  └─ Track Usage    │   │
│                   │                      │                     │   │
│  ┌─────────────────┐  ┌──────────────────┐  ┌─────────────────┐   │
│  │ Task Service    │  │ Automation Svc   │  │ Analytics Svc   │   │
│  ├─ CRUD Tasks     │  ├─ Create Rules    │  ├─ Log Events     │   │
│  ├─ Filter/Sort    │  ├─ Trigger Cases   │  ├─ Aggregate Data │   │
│  └─ Priorities     │  └─ Execute Actions │  └─ Generate Stats │   │
│                                                                     │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │ Middleware                                                   │  │
│  ├─ requireAuth() - Check session                              │  │
│  ├─ requirePlan() - Verify premium access                      │  │
│  ├─ checkUsageQuota() - Enforce limits                         │  │
│  └─ withPlan() - Decorator for protected routes                │  │
│  └──────────────────────────────────────────────────────────────┘  │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
                              ↓↓↓
┌─────────────────────────────────────────────────────────────────────┐
│                       Data Layer (Prisma ORM)                       │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ┌───────────────┐  ┌──────────────┐  ┌───────────────┐            │
│  │ User Table    │  │ Task Table   │  │ Automation    │            │
│  ├─ id          │  ├─ id         │  ├─ id          │            │
│  ├─ email       │  ├─ userId     │  ├─ userId      │            │
│  ├─ password    │  ├─ title      │  ├─ name        │            │
│  ├─ plan        │  ├─ status     │  ├─ trigger     │            │
│  ├─ stripe*     │  ├─ priority   │  ├─ action      │            │
│  └─ usage       │  └─ aiSummary  │  └─ condition   │            │
│                                                                     │
│  ┌──────────────────┐  ┌──────────────────┐  ┌─────────────────┐   │
│  │ Analytics Table  │  │ BillingHistory   │  │ WebhookEvent    │   │
│  ├─ id             │  ├─ id              │  ├─ id             │   │
│  ├─ userId         │  ├─ userId          │  ├─ stripeEventId  │   │
│  ├─ date           │  ├─ stripeInvoiceId │  ├─ type           │   │
│  ├─ tasksCreated   │  ├─ amount          │  ├─ data           │   │
│  ├─ tasksCompleted │  ├─ status          │  └─ processed      │   │
│  ├─ aiRequests     │  └─ plan            │                     │   │
│  └─ focusTime      │                     │                     │   │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
                              ↓↓↓
┌─────────────────────────────────────────────────────────────────────┐
│                    Database (PostgreSQL)                            │
├─────────────────────────────────────────────────────────────────────┤
│  All data persisted in production-grade PostgreSQL database        │
│  With indexes on userId, subscriptionStatus, date fields           │
└─────────────────────────────────────────────────────────────────────┘


External Services:
┌──────────────────┐                    ┌──────────────────┐
│  Stripe API      │  ← Payment Flow    │  NextAuth.js     │
├──────────────────┤                    ├──────────────────┤
│ • Products       │                    │ • JWT Generation │
│ • Prices         │                    │ • Session Mgmt   │
│ • Checkout       │                    │ • OAuth Ready    │
│ • Webhooks       │                    └──────────────────┘
│ • Billing Portal │
└──────────────────┘
```

---

## 💳 COMPLETE PAYMENT FLOW

```
┌──────────────────────────────────────────────────────────────────────┐
│                      USER PAYMENT JOURNEY                            │
└──────────────────────────────────────────────────────────────────────┘

STEP 1: User Views Pricing
┌──────────────────┐
│  /pricing        │
│  • Free Plan     │  ←─ User already in FREE plan
│  • Pro: $19/mo   │  ←─ User sees "Start Pro Trial"
│  • Biz: $49/mo   │
└──────────────────┘
        ↓

STEP 2: User Clicks Upgrade
┌──────────────────────────────────┐
│  onClick="handleUpgrade()"        │
│  ├─ Fetch /api/stripe/create-    │
│  │  checkout                      │
│  │  ├─ Verify user authenticated │
│  │  ├─ Create Stripe session      │
│  │  └─ Return checkout URL        │
│  └─ Redirect to Stripe            │
└──────────────────────────────────┘
        ↓

STEP 3: Stripe Checkout (Hosted)
┌──────────────────────────────────┐
│  Stripe Checkout Page            │
│  ├─ Email: john@example.com      │
│  ├─ Plan: Pro ($19.99/month)     │
│  ├─ Card Number: [44]            │
│  ├─ Exp: [MM/YY]                 │
│  ├─ CVC: [123]                   │
│  └─ [Pay $19.99]                 │
└──────────────────────────────────┘
        ↓
    Stripe charges card
        ↓

STEP 4: Stripe Sends Webhook
┌──────────────────────────────────┐
│  Webhook Event                   │
│  {                               │
│    "type": "checkout.session.    │
│              completed",          │
│    "data": {                     │
│      "object": {                │
│        "id": "cs_test_...",      │
│        "customer_email": "john...",
│        "subscription": "sub_...", │
│        "metadata": {             │
│          "userId": "user_123",  │
│          "plan": "pro"           │
│        }                         │
│      }                           │
│    }                             │
│  }                               │
└──────────────────────────────────┘
        ↓

STEP 5: App Processes Webhook
┌────────────────────────────────────┐
│  POST /api/stripe/webhook          │
│  ├─ Verify signature               │
│  │  └─ Match STRIPE_WEBHOOK_SECRET │
│  ├─ Parse event                    │
│  ├─ Handle checkout.session.       │
│  │  completed                      │
│  │  ├─ Get subscription ID         │
│  │  ├─ Retrieve full subscription  │
│  │  └─ Update user record          │
│  └─ Record webhook event           │
└────────────────────────────────────┘
        ↓

STEP 6: Database Updated
┌────────────────────────────────────┐
│  User Record BEFORE:               │
│  ├─ plan: 'FREE'                  │
│  ├─ stripeCustomerId: null        │
│  ├─ subscriptionId: null          │
│  └─ subscriptionStatus: null      │
│                                    │
│  User Record AFTER:               │
│  ├─ plan: 'PRO'                   │
│  ├─ stripeCustomerId:             │
│  │  'cus_test_...'                │
│  ├─ subscriptionId:               │
│  │  'sub_test_...'                │
│  ├─ subscriptionStatus: 'active'  │
│  ├─ currentPeriodStart: 2026-03-03│
│  ├─ currentPeriodEnd:   2026-04-03│
│  └─ cancelAtPeriodEnd: false      │
│                                    │
│  Invoice Created:                 │
│  ├─ userId: 'user_123'            │
│  ├─ amount: 1999 (cents)          │
│  ├─ status: 'paid'                │
│  ├─ plan: 'PRO'                   │
│  └─ paidAt: 2026-03-03            │
└────────────────────────────────────┘
        ↓

STEP 7: Feature Access Updated
┌────────────────────────────────────┐
│  User Now Has Access To:           │
│  ├─ ✅ Unlimited tasks             │
│  ├─ ✅ 500 AI requests/month       │
│  ├─ ✅ Up to 5 automations         │
│  ├─ ✅ Focus mode                  │
│  ├─ ✅ Advanced analytics          │
│  ├─ ✅ Priority AI response        │
│  └─ ❌ No longer: watermark        │
└────────────────────────────────────┘
        ↓

STEP 8: Success Screen
┌────────────────────────────────────┐
│  /dashboard?session_id=cs_test_... │
│                                    │
│  ✅ Payment Successful!            │
│                                    │
│  You're now on the Pro Plan        │
│  • Renews on: Apr 3, 2026          │
│  • Amount: $19.99/month            │
│                                    │
│  [Go to Dashboard]                 │
└────────────────────────────────────┘
        ↓

STEP 9: Monthly Billing Cycle
┌────────────────────────────────────┐
│  Day 30: Renewal Period Starts     │
│                                    │
│  Stripe auto-charges user card     │
│  Webhooks sent:                    │
│  • invoice.payment_succeeded       │
│  • invoice.payment_paid            │
│                                    │
│  App receives invoice details      │
│  Updates:                          │
│  ├─ subscriptionStatus: 'active'  │
│  ├─ currentPeriodEnd: 2026-05-03   │
│  └─ Creates new billing history    │
│                                    │
│  User continues with Pro access    │
└────────────────────────────────────┘
```

---

## 📊 USAGE QUOTA TRACKING

```
Timeline: Monthly Cycle (e.g., Mar 3 - Apr 3)

User: john@example.com | Plan: PRO
Limits: 500 AI requests, Unlimited tasks, 5 automations

┌─ Mar 3 (Start of Month)
│  usageCount: 0
│  taskCreatedCount: 0
│  automationCount: 0
│  lastUsageReset: Mar 3, 12:00AM
│
├─ Mar 5 (Mid-Month)
│  ├─ User creates 5 tasks
│  │  POST /api/tasks → Check quota
│  │  ├─ [Allowed, current: 0, limit: unlimited]
│  │  ├─ Create task
│  │  └─ Increment taskCreatedCount → 5
│  │
│  └─ User makes 10 AI requests
│     POST /api/ai/chat → Check quota
│     ├─ [Allowed, current: 0, limit: 500]
│     ├─ Get AI response
│     └─ Increment usageCount → 10
│
├─ Mar 25 (Near Month End)
│  usageCount: 450
│  taskCreatedCount: 120
│  automationCount: 3
│  [Usage is high but within limits]
│
├─ Apr 2 (Day Before Reset)
│  usageCount: 495
│  taskCreatedCount: 300
│  automationCount: 5
│  [At limits, user can't make more AI requests]
│
└─ Apr 3 (Renewal - Automatic Reset)
   Stripe charges user again
   Webhook: subscription renewed
   checkUsageQuota() detects new month:
   
   if (currentMonth != lastUsageReset.month) {
     usageCount = 0
     taskCreatedCount = 0
     automationCount = 0
     lastUsageReset = Apr 3, 12:00AM
   }
   
   New counters:
   usageCount: 0
   taskCreatedCount: 0
   automationCount: 0
   [User can make 500 AI requests again!]
```

---

## 🔄 WEBHOOK EVENT HANDLING

```
Stripe Dashboard
(https://dashboard.stripe.com/webhooks)

Event 1: checkout.session.completed
┌─────────────────────────────────────┐
│ {                                   │
│   "type": "checkout.session.        │
│            completed",               │
│   "data": {                         │
│     "object": {                     │
│       "id": "cs_test_xxx",         │
│       "subscription": "sub_xxx",   │
│       "metadata": {"userId": "1"}  │
│     }                               │
│   }                                 │
│ }                                   │
│                                     │
│ App action:                         │
│ ├─ Create subscription record       │
│ ├─ Update user.plan = PRO          │
│ ├─ Set stripeCustomerId            │
│ └─ Set subscriptionStatus = active  │
└─────────────────────────────────────┘

Event 2: invoice.payment_succeeded
┌─────────────────────────────────────┐
│ {                                   │
│   "type": "invoice.payment_         │
│            succeeded",               │
│   "data": {                         │
│     "object": {                     │
│       "id": "in_test_xxx",         │
│       "subscription": "sub_xxx",   │
│       "amount_paid": 1999,         │
│       "paid": true                  │
│     }                               │
│   }                                 │
│ }                                   │
│                                     │
│ App action:                         │
│ ├─ Record invoice in billingHistory │
│ ├─ Update status = paid            │
│ ├─ Set paidAt = now                │
│ └─ Confirm subscription still active│
└─────────────────────────────────────┘

Event 3: invoice.payment_failed
┌─────────────────────────────────────┐
│ {                                   │
│   "type": "invoice.payment_failed", │
│   "data": {                         │
│     "object": {                     │
│       "id": "in_test_xxx",         │
│       "subscription": "sub_xxx",   │
│       "amount_due": 1999,          │
│       "charged": false              │
│     }                               │
│   }                                 │
│ }                                   │
│                                     │
│ App action:                         │
│ ├─ Record invoice in billingHistory │
│ ├─ Update status = unpaid          │
│ ├─ Update user.subscriptionStatus   │
│ │  = past_due                       │
│ └─ [Send email: Payment failed]     │
└─────────────────────────────────────┘

Event 4: customer.subscription.updated
┌─────────────────────────────────────┐
│ {                                   │
│   "type": "customer.subscription.   │
│            updated",                 │
│   "data": {                         │
│     "object": {                     │
│       "id": "sub_xxx",             │
│       "items": [                    │
│         {                           │
│           "price": {               │
│             "id": "price_pro_xxx"  │
│           }                         │
│         }                           │
│       ],                            │
│       "current_period_end": 1743... │
│     }                               │
│   }                                 │
│ }                                   │
│                                     │
│ App action:                         │
│ ├─ Detect plan change               │
│ ├─ Update user.plan = NEW_PLAN     │
│ ├─ Update currentPeriodEnd          │
│ └─ Log change in billingHistory     │
└─────────────────────────────────────┘

Event 5: customer.subscription.deleted
┌─────────────────────────────────────┐
│ {                                   │
│   "type": "customer.subscription.   │
│            deleted",                 │
│   "data": {                         │
│     "object": {                     │
│       "id": "sub_xxx",             │
│       "canceled_at": 1743000000    │
│     }                               │
│   }                                 │
│ }                                   │
│                                     │
│ App action:                         │
│ ├─ Update subscriptionStatus =      │
│ │  canceled                         │
│ ├─ Keep access until end of period  │
│ ├─ Manual downgrade at period end   │
│ └─ Log cancellation                 │
└─────────────────────────────────────┘
```

---

## 🛡️ REQUEST AUTHORIZATION FLOW

```
User Request to Protected Route
│
├─ GET /api/tasks
│  ├─ getServerSession(authOptions)
│  ├─ Check if session exists
│  ├─ Check if user.id exists
│  ├─ Query user from database
│  ├─ Check user.plan
│  ├─ Check subscriptionStatus
│  │  ├─ If FREE: Full access
│  │  ├─ If PRO: Check subscription active
│  │  └─ If BUSINESS: Check subscription active
│  ├─ Allow ✅ or Reject ❌
│  └─ Return data or error
│
├─ POST /api/automations
│  ├─ Authenticate (same as above)
│  ├─ Check requirePlan(['PRO', 'BUSINESS'])
│  │  └─ FREE users get 403 Forbidden
│  ├─ Check usage quota
│  │  ├─ PRO: Max 5 automations
│  │  └─ BUSINESS: Unlimited
│  ├─ Create automation
│  └─ Increment automationCount
│
├─ POST /api/ai/chat
│  ├─ Authenticate
│  ├─ Check usage quota (aiRequests)
│  │  ├─ FREE: Max 20/month
│  │  ├─ PRO: Max 500/month
│  │  └─ BUSINESS: Unlimited
│  ├─ If quota exceeded:
│  │  └─ Return 429 Too Many Requests
│  ├─ Process request
│  ├─ Increment usageCount
│  └─ Return response
│
└─ Protected Routes Summary:
   ┌──────────────────────────────────┐
   │ Route          │ Auth │ Plan  │  │
   ├──────────────────────────────────┤
   │ /api/tasks     │ YES  │ None  │  │
   │ /api/ai/chat   │ YES  │ None  │  │
   │ /api/automati  │ YES  │ PRO+  │  │
   │ /api/analytics │ YES  │ PRO+  │  │
   │ /api/stripe/*  │ YES  │ None  │  │
   └──────────────────────────────────┘
```

---

## 📈 DATABASE RELATIONSHIPS

```
User (Primary)
├─ 1 → Many Tasks
│  └─ User can have 100+ tasks
│
├─ 1 → Many Automations
│  └─ User can have 0-5 (PRO) or unlimited (BUSINESS)
│
├─ 1 → Many Analytics
│  └─ User gets 1 analytics record per day
│
├─ 1 → Many BillingHistory
│  └─ User gets invoice per billing cycle
│
└─ 1 → 1 Stripe Subscription
   ├─ stripeCustomerId (Stripe Customer ID)
   ├─ subscriptionId (Stripe Subscription ID)
   └─ Plan status & dates
```

This is your complete, production-ready AI SaaS! 🚀
