# Stripe Integration - Complete Checklist

## ✅ Stripe Account Setup

- [ ] Create Stripe account: https://stripe.com
- [ ] Email verified
- [ ] Country/address filled
- [ ] Phone number verified
- [ ] Bank account connected (for payouts)
- [ ] Business type selected

---

## 🔑 API Keys Configuration

### Get Your Keys
1. Go to https://dashboard.stripe.com/apikeys
2. Ensure **Test Mode** is ON (toggle on right)
3. Copy **Publishable Key** (pk_test_...)
4. Copy **Secret Key** (sk_test_...)

### Add to .env.local
```env
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_51AbCdEfGhIjKlMnOpQrStUvWxYz...
STRIPE_SECRET_KEY=sk_test_98ZyXwVuTsRqPoNmLkJiHgFeDcBa...
```

### Security Rules
✅ Do:
- Publishable key in client code (it's public)
- Secret key only in .env and backend
- Use different keys for test/production

❌ Don't:
- Commit .env to git
- Share secret keys
- Use production keys in development

---

## 📦 Create Products & Prices

### Option A: Dashboard (Manual)

1. Go to https://dashboard.stripe.com/products
2. Click "Create product"

**Create Pro Plan:**
- Name: "Pro Plan"
- Description: "Best for professionals"
- Type: Recurring
- Price: $19.99 USD
- Billing period: Monthly
- Save

**Copy Price ID**: price_1234567890...

**Create Business Plan:**
- Name: "Business Plan"
- Description: "For growing teams"
- Type: Recurring
- Price: $49.99 USD
- Billing period: Monthly
- Save

**Copy Price ID**: price_9876543210...

### Option B: Automated Script

```bash
npm run stripe:init
```

This creates products and outputs price IDs automatically.

### Add Price IDs to .env.local

```env
STRIPE_PRICE_PRO=price_1AbCdEfGhIjKlMnOpQrStUv...
STRIPE_PRICE_BUSINESS=price_9ZyXwVuTsRqPoNmLkJiHg...
```

---

## 🪝 Setup Webhooks

Webhooks are **CRITICAL** for:
- Creating subscriptions after payment
- Updating billing status
- Cancellation handling
- Renewal processing

### For Local Development

```bash
# Install Stripe CLI
# macOS
brew install stripe/stripe-cli/stripe

# Windows
choco install stripe-cli

# Linux
curl https://raw.githubusercontent.com/stripe/stripe-cli/master/install.sh | sh
```

### Run Stripe CLI

```bash
# Terminal 1: Your app
npm run dev

# Terminal 2: Forward webhooks to localhost
stripe login
stripe listen --forward-to localhost:3000/api/stripe/webhook
```

Copy the output:
```
> Ready! Your webhook signing secret is:
whsec_test_1234567890abcdefghijklmn...
```

### Add to .env.local
```env
STRIPE_WEBHOOK_SECRET=whsec_test_1234567890abcdefghijklmn...
```

### For Production (Deployed App)

1. Go to https://dashboard.stripe.com/webhooks
2. Click "Add endpoint"
3. Endpoint URL: `https://yourdomain.com/api/stripe/webhook`
4. Events to send: Select these:
   - [ ] `checkout.session.completed`
   - [ ] `invoice.payment_succeeded`
   - [ ] `invoice.payment_failed`
   - [ ] `customer.subscription.updated`
   - [ ] `customer.subscription.deleted`
5. Click "Add events"
6. Click "Create endpoint"
7. Copy webhook secret
8. Add to production .env: `STRIPE_WEBHOOK_SECRET=whsec_live_...`

---

## 🧪 Test Payment Flow

### Startup
```bash
npm install
npm run db:push
npm run dev
npm run stripe:init  # If needed
```

### Test Scenario 1: New User → Pro Plan

1. Go to http://localhost:3000/pricing
2. Click "Start Pro Trial"
3. Fill signup form:
   - Email: test@example.com
   - Password: Test@12345

4. Redirected to Stripe Checkout
5. Fill payment info:
   - Card: `4242 4242 4242 4242`
   - Exp: `12/25`
   - CVC: `123`
   - Name: Test User
   - Email: test@example.com

6. Click "Pay"
7. Should see success page
8. Check database:
   ```bash
   npx prisma studio
   # Go to User table
   # Verify: plan=PRO, stripeCustomerId populated
   ```

### Test Scenario 2: Webhook Delivery

When you submit payment:

**Terminal 2 (stripe listen) should show:**
```
> ...
> checkout.session.completed [evt_1234567890...]
> Signature verified! ✓
```

If webhook fails to show:
```bash
# Check webhook logs
stripe logs --filter-resource checkout.session

# Or manually trigger test
stripe trigger checkout.session.completed
```

### Test Scenario 3: Failed Payment

1. Use card: `4000 0000 0000 0002`
2. Complete checkout
3. Payment should fail
4. Check Stripe dashboard for error

---

## 🔍 Verify Integration

### Checklist

- [ ] **API Keys Work**
  ```bash
  curl https://api.stripe.com/v1/customers \
    -u sk_test_...:
  # Should return JSON, not 401 Unauthorized
  ```

- [ ] **Publishable Key in Client**
  Check browser console:
  ```javascript
  fetch('http://localhost:3000/api/user/profile')
  // Should work if logged in
  ```

- [ ] **Webhooks Receiving**
  ```bash
  stripe trigger checkout.session.completed
  # Should log in your terminal running npm run dev
  ```

- [ ] **Database Updating**
  ```bash
  npx prisma studio
  # Check User → plan changed to PRO
  # Check BillingHistory → invoice created
  ```

- [ ] **Prices Set Correctly**
  ```bash
  echo $STRIPE_PRICE_PRO
  echo $STRIPE_PRICE_BUSINESS
  # Should output: price_...
  ```

---

## 🚀 Test Cards

Use these for testing without spending real money:

### Successful Payments
- **4242 4242 4242 4242** - Basic success
- **4000 0027 6000 3184** - Check charge
- **5555 5555 5555 4444** - Mastercard success

### Declined Payments
- **4000 0000 0000 0002** - Generic decline
- **4000 0000 0000 9995** - Risk level increase
- **4000 0000 0000 9987** - Lost card

### Special Cases
- **4000 0025 0000 3155** - 3D Secure required
- **3782 822463 10005** - American Express
- **6011 1111 1111 1117** - Discover

All test cards:
- **Expiration**: Any future date
- **CVC**: Any 3 digits
- **Zip**: Any 5 digits

---

## 📊 Monitor Webhooks

### In Stripe Dashboard
1. Go to https://dashboard.stripe.com/webhooks
2. Click your endpoint
3. Check recent webhook deliveries:
   - ✅ Success (green)
   - ❌ Failed (red)
   - ⏳ Pending (yellow)

### View Failed Webhook
- Click the event ID
- See error details
- Can manually retry

### Common Webhook Issues

**Issue**: `400 Bad Request`
- Fix: Check endpoint URL matches exactly
- Fix: Verify server is running

**Issue**: `Signature Verification Failed`
- Fix: Verify `STRIPE_WEBHOOK_SECRET` matches
- Fix: Ensure both test/production secrets correct

**Issue**: `Timeout`
- Fix: Endpoint taking too long
- Fix: Optimize database queries

---

## 💾 Database Verification

After successful payment:

```bash
npx prisma studio
```

**Check these tables:**

### User Table
```
id                 [id]
email              test@example.com
plan               PRO ✓
stripeCustomerId   cus_... ✓
subscriptionId     sub_... ✓
subscriptionStatus active ✓
currentPeriodEnd   [future date] ✓
usageCount         0
```

### BillingHistory Table
```
userId             [user id]
stripeInvoiceId    in_... ✓
amount             1999 (in cents) ✓
status             paid ✓
plan               PRO ✓
createdAt          [now] ✓
```

### WebhookEvent Table
```
stripeEventId      evt_... ✓
type               checkout.session.completed ✓
processed          true ✓
```

---

## 🔐 Security Verification

### Check These:

- [ ] Webhook signature verified in code
  ```typescript
  // In /api/stripe/webhook/route.ts
  const event = stripe.webhooks.constructEvent(
    body, signature, webhookSecret
  );
  ```

- [ ] Secret key never logged
  ```bash
  grep -r "STRIPE_SECRET_KEY" src/ # Should be imports only
  ```

- [ ] Publishable key in .env.local only
  ```bash
  echo $NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY
  # OK: Shows key (it's public)
  ```

- [ ] Plan validation happens server-side
  ```typescript
  // NOT in browser JS, only in /api routes
  ```

---

## 📈 Production Checklist

### Before Going Live

- [ ] Switch from Test to Live mode
  - Go to API keys page
  - Copy pk_live_ keys
  - Copy sk_live_ keys

- [ ] Update Environment Variables
  ```env
  NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_live_...
  STRIPE_SECRET_KEY=sk_live_...
  STRIPE_WEBHOOK_SECRET=whsec_live_...
  ```

- [ ] Test with Live Keys (Staging)
  - Deploy to staging environment
  - Test full payment flow
  - IMPORTANT: Use test card 4242...
  - DO NOT use real credit card

- [ ] Setup Production Webhook
  - New endpoint: https://yourdomain.com/api/stripe/webhook
  - Same events
  - New webhook secret

- [ ] Enable Email Notifications
  - Confirmation emails
  - Invoice emails
  - Failure notifications

- [ ] Monitor Closely
  - First 24 hours: watch all payments
  - Check webhook logs hourly
  - Verify funds in bank account

---

## 🚨 Troubleshooting

### Payment Button Doesn't Work

**Check:**
```bash
# 1. Is STRIPE_PRICE_PRO set?
echo $STRIPE_PRICE_PRO

# 2. Is it correct format?
# Should be: price_1234567890...

# 3. Does it exist in Stripe?
stripe prices retrieve price_1234567890...
```

### Webhook Not Firing

**Check:**
```bash
# 1. Is Stripe CLI running?
stripe listen --forward-to localhost:3000/api/stripe/webhook

# 2. Manually trigger test event
stripe trigger checkout.session.completed

# 3. Check server logs
npm run dev
# Look for "webhook" in output
```

### Database Not Updating

**Check:**
```bash
# 1. Is database connected?
npx prisma db push

# 2. Is webhook processing error?
stripe logs --filter-resource checkout.session

# 3. Check webhook handler for errors
# Review /src/lib/webhook-handler.ts
```

### Users Seeing "Unauthorized"

**Check:**
```bash
# 1. Is NEXTAUTH_SECRET set?
echo $NEXTAUTH_SECRET

# 2. Is session valid?
# Check browser cookies
# Application → Cookies → localhost

# 3. Is user in database?
npx prisma studio → User table
```

---

## 📞 Support Resources

- **Stripe Docs**: https://stripe.com/docs
- **API Reference**: https://stripe.com/docs/api
- **Webhook Docs**: https://stripe.com/docs/webhooks
- **CLI Guide**: https://stripe.com/docs/stripe-cli
- **Test Cards**: https://stripe.com/docs/testing

---

## ✅ Final Checklist

- [ ] Stripe account created
- [ ] API keys copied to .env.local
- [ ] Products created (Pro, Business)
- [ ] Price IDs copied to .env.local
- [ ] Webhooks configured locally
- [ ] Webhook secret in .env.local
- [ ] Test payment flow works
- [ ] Database updates after payment
- [ ] Webhook logs show success
- [ ] Production keys ready
- [ ] Production webhook endpoint set
- [ ] Documentation reviewed
- [ ] Team trained on system
- [ ] Ready to deploy! 🚀

---

**Everything configured? You're ready to accept real payments!** 💳
