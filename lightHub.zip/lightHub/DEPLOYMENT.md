# Deployment Guide - lightHub

## 🚀 Deployment Options

### Option 1: Vercel (Recommended - Easiest)

#### Prerequisites
- Vercel account (free at https://vercel.com)
- GitHub account with repo pushed

#### Steps

1. **Connect to Vercel**
   - Go to https://vercel.com
   - Click "New Project"
   - Select your GitHub repository
   - Click "Import"

2. **Configure Environment Variables**
   - In Vercel dashboard, go to Project Settings
   - Click "Environment Variables"
   - Add all variables from `.env.local`:
     - `DATABASE_URL`
     - `NEXTAUTH_SECRET` (generate: `openssl rand -base64 32`)
     - `NEXTAUTH_URL` (your production domain)
     - Stripe keys (PRODUCTION keys from Live mode)
     - All other variables
   - Click "Save"

3. **Configure Database**
   - Use Vercel Postgres (built-in) or external PostgreSQL
   - If using external: ensure it's accessible from Vercel

4. **Deploy**
   - Click "Deploy"
   - Vercel will automatically build and deploy
   - Your app is now live!

5. **Post-Deployment**
   - Update Stripe webhook URL to: `https://yourdomain.com/api/stripe/webhook`
   - Test checkout flow
   - Monitor Stripe dashboard

### Option 2: Railway

#### Prerequisites
- Railway account (https://railway.app)
- GitHub repository

#### Steps

1. **Create Project**
   - Go to https://railway.app/new
   - Select "Deploy from GitHub"
   - Select your repository

2. **Add Database**
   - Click "Add Service"
   - Select "PostgreSQL"
   - Railway creates `DATABASE_URL` automatically

3. **Set Environment Variables**
   - Click "Variables" tab
   - Add all variables:
     ```
     NEXTAUTH_SECRET=<generated>
     NEXTAUTH_URL=https://yourdomain.railway.app
     NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_live_...
     STRIPE_SECRET_KEY=sk_live_...
     STRIPE_WEBHOOK_SECRET=whsec_...
     STRIPE_PRICE_PRO=price_...
     STRIPE_PRICE_BUSINESS=price_...
     ```

4. **Deploy**
   - Click "Deploy"
   - Railway automatically deploys on git push

5. **Configure Domain**
   - In Railway, go to project settings
   - Add custom domain
   - Update DNS records

### Option 3: Self-Hosted (Docker)

#### Prerequisites
- Docker & Docker Compose
- Server (e.g., AWS EC2, DigitalOcean, Linode)
- Domain name
- PostgreSQL database (or containerized)

#### Docker Setup

1. **Create Dockerfile** (already provided)

2. **Create docker-compose.yml**
   ```yaml
   version: '3.8'
   services:
     app:
       build: .
       ports:
         - "3000:3000"
       environment:
         DATABASE_URL: postgres://user:pass@db:5432/lighthub
         NEXTAUTH_SECRET: your-secret
         NEXTAUTH_URL: https://yourdomain.com
         # ... all other env vars
       depends_on:
         - db
     
     db:
       image: postgres:15-alpine
       environment:
         POSTGRES_DB: lighthub
         POSTGRES_USER: user
         POSTGRES_PASSWORD: password
       volumes:
         - postgres_data:/var/lib/postgresql/data
   
   volumes:
     postgres_data:
   ```

3. **Deploy**
   ```bash
   docker-compose up -d
   ```

4. **Setup HTTPS**
   - Use Nginx as reverse proxy
   - Setup SSL with Let's Encrypt
   - Configure domain DNS

### Option 4: AWS Deployment

#### Using AWS Amplify (Easiest on AWS)

1. Go to AWS Amplify Console
2. Connect GitHub repository
3. Configure build settings:
   ```
   build:
     commands:
       - npm ci
       - npm run build
   appRoot: ./
   ```
4. Add environment variables
5. Deploy

#### Using AWS EC2 + RDS

1. Create EC2 instance (Ubuntu 22.04)
2. Create RDS PostgreSQL database
3. Install Node.js & PM2:
   ```bash
   curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
   sudo apt-get install -y nodejs
   sudo npm install -g pm2
   ```
4. Clone repo and setup:
   ```bash
   git clone <repo>
   cd lighthub
   npm install
   npm run build
   ```
5. Create PM2 ecosystem file:
   ```json
   {
     "apps": [{
       "name": "lighthub",
       "script": "npm start",
       "instances": "max",
       "exec_mode": "cluster"
     }]
   }
   ```
6. Start with PM2:
   ```bash
   pm2 start ecosystem.config.json
   pm2 startup
   pm2 save
   ```
7. Setup Nginx as reverse proxy
8. Configure SSL with Let's Encrypt

### Option 5: Heroku (Legacy - Paid)

Heroku discontinued free tier, but still available with paid dynos.

## 🔒 Production Security Checklist

- [ ] Use PRODUCTION Stripe keys (not test keys)
- [ ] Generate new `NEXTAUTH_SECRET` for production
- [ ] Set `NEXTAUTH_URL` to your production domain
- [ ] Enable HTTPS everywhere
- [ ] Setup database backups
- [ ] Monitor error logs
- [ ] Setup uptime monitoring
- [ ] Configure CORS properly
- [ ] Enable database encryption
- [ ] Setup WAF (Web Application Firewall)
- [ ] Use environment variables (never hardcode secrets)
- [ ] Enable 2FA for Stripe account
- [ ] Configure webhook signatures verification
- [ ] Monitor API rate limits

## 📊 Monitoring Production

### Stripe Monitoring
1. Go to https://dashboard.stripe.com
2. Monitor:
   - Payment success rate
   - Webhook delivery status
   - Failed payments
   - Customer disputes

### Application Monitoring
- Setup Sentry for error tracking
- Use LogRocket for session replay
- Monitor database performance
- Setup alerts for critical errors

### Uptime Monitoring
- Service: https://uptimerobot.com
- Monitor: https://yourdomain.com
- Alert email on downtime

## 🔄 Continuous Deployment

### With GitHub Actions (Auto-deploy on push)

Create `.github/workflows/deploy.yml`:

```yaml
name: Deploy to Production
on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
      - run: npm ci
      - run: npm run build
      - run: npm run db:push
      # Additional deployment steps
```

## 📈 Performance Optimization

1. **Database Optimization**
   - Add indexes on frequently queried columns
   - Monitor slow queries
   - Optimize N+1 queries

2. **Caching**
   - Implement Redis for session/cache
   - Cache user plan data
   - Cache static assets

3. **CDN**
   - Use Vercel's built-in CDN
   - Or add Cloudflare for custom domains

4. **API Optimization**
   - Implement pagination
   - Add rate limiting
   - Compress responses

## 🆘 Troubleshooting

### Database Connection Issues
```bash
# Check connection string
psql $DATABASE_URL

# Run migrations
npx prisma migrate deploy
```

### Stripe Webhook Not Received
1. Verify webhook secret is correct
2. Check firewall/security rules
3. Verify endpoint is publicly accessible
4. Check Stripe webhook logs

### Session/Auth Issues
1. Verify `NEXTAUTH_SECRET` is set
2. Check `NEXTAUTH_URL` matches domain
3. Clear browser cookies
4. Restart application

### Database Locked
```bash
# Kill idle connections
SELECT pg_terminate_backend(pid) 
FROM pg_stat_activity 
WHERE datname = 'lighthub' 
  AND pid <> pg_backend_pid();
```

## 🚨 Emergency Procedures

### Database Recovery
```bash
# Backup
pg_dump $DATABASE_URL > backup.sql

# Restore
psql $DATABASE_URL < backup.sql
```

### Rollback Deployment
- Vercel: Click "Rollbacks" tab
- Railway: Select previous deployment
- Self-hosted: Use git tags and redeploy

### Disable Billing (Emergency)
If Stripe is compromised:
```bash
# Set all users to FREE plan
npx prisma db execute 'UPDATE "User" SET plan = '"'FREE'"';'
```

---

## Quick Deploy Reference

**Vercel**: Connect GitHub repo → Set env vars → Done ✓

**Railway**: Same as Vercel → PostgreSQL auto-added

**Self-hosted**: Docker Compose → Configure Nginx → Setup SSL

**AWS**: Use Amplify (easiest) or EC2 + RDS

Choose based on your needs!
