import Stripe from 'stripe';

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || '', {
  apiVersion: '2023-10-16',
});

// Define pricing tiers
export const PRICING_PLANS = {
  free: {
    name: 'Free',
    price: 0,
    monthlyUsage: {
      aiRequests: 20,
      tasksPerMonth: 50,
      automations: 0,
    },
    features: [
      'Limited tasks (50/month)',
      '20 AI requests per month',
      'Basic dashboard',
      'No automations',
      'Watermark in exports',
    ],
  },
  pro: {
    name: 'Pro',
    price: 1999, // $19.99 in cents
    monthlyUsage: {
      aiRequests: 500,
      tasksPerMonth: -1, // unlimited
      automations: 5,
    },
    features: [
      'Unlimited tasks',
      '500 AI requests per month',
      'Automations enabled',
      'Focus mode',
      'Analytics',
      'Priority AI response',
    ],
  },
  business: {
    name: 'Business',
    price: 4999, // $49.99 in cents
    monthlyUsage: {
      aiRequests: -1, // unlimited
      tasksPerMonth: -1, // unlimited
      automations: -1, // unlimited
    },
    features: [
      'Unlimited AI requests',
      'Team collaboration',
      'Shared projects',
      'Admin dashboard',
      'Advanced analytics',
      'API access',
      'Priority support',
    ],
  },
};

// Initialize Stripe products and prices (run once)
export async function initializeStripeProducts() {
  const productIds: Record<string, string> = {};

  for (const [key, plan] of Object.entries(PRICING_PLANS)) {
    if (key === 'free') continue;

    try {
      // Create or get product
      const products = await stripe.products.list({
        limit: 1,
        expand: ['data.default_price'],
      });

      const existingProduct = products.data.find(
        (p) => p.name === plan.name && p.metadata?.plan === key
      );

      let productId: string;

      if (existingProduct) {
        productId = existingProduct.id;
      } else {
        const product = await stripe.products.create({
          name: plan.name,
          description: `${plan.name} plan for lightHub`,
          metadata: {
            plan: key,
            aiRequests: plan.monthlyUsage.aiRequests.toString(),
            tasksPerMonth: plan.monthlyUsage.tasksPerMonth.toString(),
          },
        });
        productId = product.id;
      }

      // Create price
      const price = await stripe.prices.create({
        product: productId,
        unit_amount: plan.price,
        currency: 'usd',
        recurring: {
          interval: 'month',
          usage_type: 'licensed',
        },
        metadata: {
          plan: key,
        },
      });

      productIds[key] = price.id;
      
      // Store price IDs in env (you should store these in database or env)
      process.env[`STRIPE_PRICE_${key.toUpperCase()}`] = price.id;
    } catch (error) {
      console.error(`Error creating product for ${key}:`, error);
    }
  }

  return productIds;
}

// Create checkout session
export async function createCheckoutSession(
  userId: string,
  email: string,
  planKey: string
) {
  const priceId = process.env[`STRIPE_PRICE_${planKey.toUpperCase()}`];

  if (!priceId) {
    throw new Error(`Price ID not found for plan: ${planKey}`);
  }

  const session = await stripe.checkout.sessions.create({
    customer_email: email,
    mode: 'subscription',
    line_items: [
      {
        price: priceId,
        quantity: 1,
      },
    ],
    success_url: `${process.env.NEXTAUTH_URL}/dashboard?session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: `${process.env.NEXTAUTH_URL}/pricing?cancelled=true`,
    metadata: {
      userId,
      plan: planKey,
    },
  });

  return session;
}

// Create billing portal session
export async function createBillingPortalSession(customerId: string) {
  const session = await stripe.billingPortal.sessions.create({
    customer: customerId,
    return_url: `${process.env.NEXTAUTH_URL}/dashboard/billing`,
  });

  return session;
}

// Get subscription details
export async function getSubscriptionDetails(subscriptionId: string) {
  const subscription = await stripe.subscriptions.retrieve(subscriptionId);
  return subscription;
}

// Cancel subscription
export async function cancelSubscription(subscriptionId: string) {
  const subscription = await stripe.subscriptions.update(subscriptionId, {
    cancel_at_period_end: true,
  });
  return subscription;
}

// Resume subscription
export async function resumeSubscription(subscriptionId: string) {
  const subscription = await stripe.subscriptions.update(subscriptionId, {
    cancel_at_period_end: false,
  });
  return subscription;
}
