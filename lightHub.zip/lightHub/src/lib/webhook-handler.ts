import { stripe } from './stripe';
import { prisma } from './db';
import Stripe from 'stripe';

export async function handleStripeWebhook(
  event: Stripe.Event
) {
  // Check if event was already processed
  const existingEvent = await prisma.webhookEvent.findUnique({
    where: { stripeEventId: event.id },
  });

  if (existingEvent?.processed) {
    return { processed: true };
  }

  try {
    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object as Stripe.Checkout.Session;
        await handleCheckoutSessionCompleted(session);
        break;
      }

      case 'invoice.payment_succeeded': {
        const invoice = event.data.object as Stripe.Invoice;
        await handleInvoicePaymentSucceeded(invoice);
        break;
      }

      case 'invoice.payment_failed': {
        const invoice = event.data.object as Stripe.Invoice;
        await handleInvoicePaymentFailed(invoice);
        break;
      }

      case 'customer.subscription.updated': {
        const subscription = event.data.object as Stripe.Subscription;
        await handleSubscriptionUpdated(subscription);
        break;
      }

      case 'customer.subscription.deleted': {
        const subscription = event.data.object as Stripe.Subscription;
        await handleSubscriptionDeleted(subscription);
        break;
      }

      default:
        console.log(`Unhandled event type ${event.type}`);
    }

    // Mark event as processed
    if (!existingEvent) {
      await prisma.webhookEvent.create({
        data: {
          stripeEventId: event.id,
          type: event.type,
          data: JSON.stringify(event.data),
          processed: true,
        },
      });
    } else {
      await prisma.webhookEvent.update({
        where: { id: existingEvent.id },
        data: { processed: true },
      });
    }

    return { processed: true };
  } catch (error) {
    console.error('Webhook error:', error);
    
    // Mark as attempted
    if (existingEvent) {
      await prisma.webhookEvent.update({
        where: { id: existingEvent.id },
        data: { processed: false },
      });
    }

    throw error;
  }
}

async function handleCheckoutSessionCompleted(
  session: Stripe.Checkout.Session
) {
  const metadata = session.metadata as any;
  const userId = metadata?.userId;

  if (!userId) {
    throw new Error('No userId in checkout session metadata');
  }

  const subscription = await stripe.subscriptions.retrieve(
    session.subscription as string
  );

  const plan = metadata.plan || 'pro';

  await prisma.user.update({
    where: { id: userId },
    data: {
      stripeCustomerId: session.customer as string,
      subscriptionId: subscription.id,
      plan: plan.toUpperCase(),
      subscriptionStatus: 'active',
      currentPeriodEnd: new Date(subscription.current_period_end * 1000),
      currentPeriodStart: new Date(subscription.current_period_start * 1000),
    },
  });

  // Record billing history
  if (subscription.latest_invoice && typeof subscription.latest_invoice !== 'string') {
    const invoice = subscription.latest_invoice as Stripe.Invoice;
    
    await prisma.billingHistory.create({
      data: {
        userId,
        stripeInvoiceId: invoice.id,
        amount: invoice.amount_paid,
        currency: invoice.currency || 'usd',
        status: 'paid',
        plan: plan.toUpperCase(),
        billingReason: 'subscription_create',
        paidAt: new Date(invoice.paid! * 1000),
      },
    });
  }
}

async function handleInvoicePaymentSucceeded(invoice: Stripe.Invoice) {
  if (!invoice.customer) return;

  const user = await prisma.user.findUnique({
    where: { stripeCustomerId: invoice.customer as string },
  });

  if (!user) {
    console.log(`User not found for customer ${invoice.customer}`);
    return;
  }

  const subscription = await stripe.subscriptions.retrieve(
    invoice.subscription as string
  );

  // Determine plan from subscription
  const lineItem = invoice.lines.data[0];
  const priceId = (lineItem.price as Stripe.Price).id;
  let plan = 'PRO';

  if (process.env.STRIPE_PRICE_BUSINESS === priceId) {
    plan = 'BUSINESS';
  } else if (process.env.STRIPE_PRICE_PRO === priceId) {
    plan = 'PRO';
  }

  await prisma.user.update({
    where: { id: user.id },
    data: {
      subscriptionStatus: 'active',
      plan,
      currentPeriodEnd: new Date(subscription.current_period_end * 1000),
    },
  });

  await prisma.billingHistory.create({
    data: {
      userId: user.id,
      stripeInvoiceId: invoice.id,
      amount: invoice.amount_paid,
      currency: invoice.currency || 'usd',
      status: 'paid',
      plan,
      billingReason: 'subscription_cycle',
      paidAt: new Date(invoice.paid! * 1000),
    },
  });
}

async function handleInvoicePaymentFailed(invoice: Stripe.Invoice) {
  if (!invoice.customer) return;

  const user = await prisma.user.findUnique({
    where: { stripeCustomerId: invoice.customer as string },
  });

  if (!user) return;

  await prisma.user.update({
    where: { id: user.id },
    data: {
      subscriptionStatus: 'past_due',
    },
  });

  await prisma.billingHistory.create({
    data: {
      userId: user.id,
      stripeInvoiceId: invoice.id,
      amount: invoice.amount_due,
      currency: invoice.currency || 'usd',
      status: 'unpaid',
      plan: user.plan,
    },
  });
}

async function handleSubscriptionUpdated(subscription: Stripe.Subscription) {
  if (!subscription.customer) return;

  const user = await prisma.user.findUnique({
    where: { stripeCustomerId: subscription.customer as string },
  });

  if (!user) return;

  // Determine plan from subscription items
  const lineItem = subscription.items.data[0];
  const priceId = lineItem.price.id;
  let plan = 'PRO';

  if (process.env.STRIPE_PRICE_BUSINESS === priceId) {
    plan = 'BUSINESS';
  } else if (process.env.STRIPE_PRICE_PRO === priceId) {
    plan = 'PRO';
  }

  await prisma.user.update({
    where: { id: user.id },
    data: {
      plan,
      subscriptionStatus: subscription.status,
      currentPeriodEnd: new Date(subscription.current_period_end * 1000),
      cancelAtPeriodEnd: subscription.cancel_at_period_end,
    },
  });
}

async function handleSubscriptionDeleted(subscription: Stripe.Subscription) {
  if (!subscription.customer) return;

  const user = await prisma.user.findUnique({
    where: { stripeCustomerId: subscription.customer as string },
  });

  if (!user) return;

  await prisma.user.update({
    where: { id: user.id },
    data: {
      subscriptionStatus: 'canceled',
      cancelAtPeriodEnd: false,
      // Plan stays the same until period ends
    },
  });
}
