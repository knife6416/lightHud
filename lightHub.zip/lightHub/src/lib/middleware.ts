import { getServerSession } from 'next-auth/next';
import { authOptions } from './auth';
import { prisma } from './db';
import { NextRequest, NextResponse } from 'next/server';
import { USAGE_LIMITS } from './usage';

export async function requireAuth(req: NextRequest) {
  const session = await getServerSession(authOptions);

  if (!session?.user?.id) {
    return NextResponse.json(
      { error: 'Unauthorized' },
      { status: 401 }
    );
  }

  return session;
}

export async function requirePlan(
  req: NextRequest,
  requiredPlans: string[]
) {
  const session = await getServerSession(authOptions);

  if (!session?.user?.id) {
    return NextResponse.json(
      { error: 'Unauthorized' },
      { status: 401 }
    );
  }

  const user = await prisma.user.findUnique({
    where: { id: session.user.id },
    select: { plan: true, subscriptionStatus: true },
  });

  if (!user) {
    return NextResponse.json(
      { error: 'User not found' },
      { status: 404 }
    );
  }

  if (!requiredPlans.includes(user.plan)) {
    return NextResponse.json(
      {
        error: 'This feature requires a premium plan',
        requiredPlan: requiredPlans,
        currentPlan: user.plan,
      },
      { status: 403 }
    );
  }

  // Check subscription status
  if (
    user.plan !== 'FREE' &&
    user.subscriptionStatus !== 'active' &&
    user.subscriptionStatus !== 'trialing'
  ) {
    return NextResponse.json(
      {
        error: 'Subscription inactive',
        subscriptionStatus: user.subscriptionStatus,
      },
      { status: 403 }
    );
  }

  return session;
}

export async function checkUsageQuota(
  userId: string,
  feature: 'aiRequests' | 'tasksPerMonth' | 'automations'
) {
  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: {
      plan: true,
      usageCount: true,
      taskCreatedCount: true,
      automationCount: true,
      lastUsageReset: true,
    },
  });

  if (!user) {
    throw new Error('User not found');
  }

  // Check if usage needs to be reset (monthly)
  const now = new Date();
  const lastReset = new Date(user.lastUsageReset);
  
  if (
    now.getMonth() !== lastReset.getMonth() ||
    now.getFullYear() !== lastReset.getFullYear()
  ) {
    // Reset usage for the new month
    await prisma.user.update({
      where: { id: userId },
      data: {
        usageCount: 0,
        taskCreatedCount: 0,
        lastUsageReset: now,
      },
    });
    user.usageCount = 0;
    user.taskCreatedCount = 0;
  }

  const limits = USAGE_LIMITS[user.plan];
  const limit = (limits as any)[feature];

  let current = 0;
  if (feature === 'aiRequests') {
    current = user.usageCount;
  } else if (feature === 'tasksPerMonth') {
    current = user.taskCreatedCount;
  } else if (feature === 'automations') {
    current = user.automationCount;
  }

  const allowed = limit === -1 || current < limit;

  return {
    allowed,
    current,
    limit,
    plan: user.plan,
  };
}

// Next.js 13+ middleware
import { NextFetchEvent } from 'next/server';

export function withAuth(handler: any) {
  return async (req: NextRequest, ...args: any[]) => {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    (req as any).user = session.user;
    return handler(req, ...args);
  };
}

export function withPlan(requiredPlans: string[], handler: any) {
  return async (req: NextRequest, ...args: any[]) => {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      select: { plan: true, subscriptionStatus: true },
    });

    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    if (!requiredPlans.includes(user.plan)) {
      return NextResponse.json(
        {
          error: 'This feature requires a premium plan',
          requiredPlans,
          currentPlan: user.plan,
        },
        { status: 403 }
      );
    }

    if (
      user.plan !== 'FREE' &&
      user.subscriptionStatus !== 'active' &&
      user.subscriptionStatus !== 'trialing'
    ) {
      return NextResponse.json(
        {
          error: 'Subscription inactive',
          subscriptionStatus: user.subscriptionStatus,
        },
        { status: 403 }
      );
    }

    (req as any).user = session.user;
    return handler(req, ...args);
  };
}
