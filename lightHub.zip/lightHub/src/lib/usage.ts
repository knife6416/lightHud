import { prisma } from './db';
import { Plan } from '@prisma/client';

export const USAGE_LIMITS = {
  [Plan.FREE]: {
    aiRequests: 20,
    tasksPerMonth: 50,
    automations: 0,
  },
  [Plan.PRO]: {
    aiRequests: 500,
    tasksPerMonth: -1, // unlimited
    automations: 5,
  },
  [Plan.BUSINESS]: {
    aiRequests: -1, // unlimited
    tasksPerMonth: -1, // unlimited
    automations: -1, // unlimited
  },
};

export async function checkUsageLimit(
  userId: string,
  feature: 'aiRequests' | 'tasksPerMonth' | 'automations'
) {
  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: {
      plan: true,
      usageCount: true,
      taskCreatedCount: true,
      automationCount: true,
      lastUsageReset: true,
    },
  });

  if (!user) {
    throw new Error('User not found');
  }

  // Check if usage needs to be reset (monthly)
  const now = new Date();
  const lastReset = new Date(user.lastUsageReset);
  const isNewMonth = now.getMonth() !== lastReset.getMonth() ||
                     now.getFullYear() !== lastReset.getFullYear();

  if (isNewMonth) {
    // Reset usage for the new month
    await prisma.user.update({
      where: { id: userId },
      data: {
        usageCount: 0,
        taskCreatedCount: 0,
        lastUsageReset: now,
      },
    });
    return { allowed: true, current: 0, limit: USAGE_LIMITS[user.plan][feature] };
  }

  const limits = USAGE_LIMITS[user.plan];
  const limit = (limits as any)[feature];

  let current = 0;
  if (feature === 'aiRequests') {
    current = user.usageCount;
  } else if (feature === 'tasksPerMonth') {
    current = user.taskCreatedCount;
  } else if (feature === 'automations') {
    current = user.automationCount;
  }

  const allowed = limit === -1 || current < limit;

  return { allowed, current, limit };
}

export async function incrementUsage(
  userId: string,
  feature: 'aiRequests' | 'tasksPerMonth' | 'automations'
) {
  const updateData: any = {};

  if (feature === 'aiRequests') {
    updateData.usageCount = { increment: 1 };
  } else if (feature === 'tasksPerMonth') {
    updateData.taskCreatedCount = { increment: 1 };
  } else if (feature === 'automations') {
    updateData.automationCount = { increment: 1 };
  }

  await prisma.user.update({
    where: { id: userId },
    data: updateData,
  });
}

export async function getUserPlan(userId: string) {
  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: {
      plan: true,
      subscriptionStatus: true,
      currentPeriodEnd: true,
      usageCount: true,
      taskCreatedCount: true,
      automationCount: true,
    },
  });

  return user;
}

export async function checkSubscriptionStatus(userId: string) {
  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: {
      plan: true,
      subscriptionStatus: true,
      currentPeriodEnd: true,
    },
  });

  if (!user) return null;

  // Check if subscription is expired
  if (
    user.subscriptionStatus === 'canceled' &&
    user.currentPeriodEnd &&
    new Date() > new Date(user.currentPeriodEnd)
  ) {
    // Downgrade to free plan
    await prisma.user.update({
      where: { id: userId },
      data: {
        plan: 'FREE',
        subscriptionStatus: 'inactive',
      },
    });

    return { plan: 'FREE', subscriptionStatus: 'inactive', isExpired: true };
  }

  return user;
}
