'use client';

import { useSession } from 'next-auth/react';
import Link from 'next/link';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import toast from 'react-hot-toast';

interface PricingCardProps {
  plan: {
    id: string;
    name: string;
    price: number;
    description: string;
    popular?: boolean;
    features: string[];
    cta: string;
  };
  isLoggedIn: boolean;
}

export function PricingCard({ plan, isLoggedIn }: PricingCardProps) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const { data: session } = useSession();

  const handleUpgrade = async () => {
    if (plan.id === 'free') {
      router.push('/signup');
      return;
    }

    if (!session?.user?.id) {
      router.push('/login');
      return;
    }

    setLoading(true);
    try {
      const response = await fetch('/api/stripe/create-checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ plan: plan.id }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to create checkout');
      }

      window.location.href = data.url;
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Failed to upgrade');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className={`rounded-lg border ${
        plan.popular ? 'border-blue-600 bg-blue-50' : 'border-gray-200'
      } p-8 flex flex-col`}
    >
      {plan.popular && (
        <div className="mb-4 inline-block rounded-full bg-blue-600 text-white text-sm font-semibold px-3 py-1 w-fit">
          Most Popular
        </div>
      )}

      <h3 className="text-2xl font-bold text-gray-900">{plan.name}</h3>
      <p className="mt-2 text-gray-600">{plan.description}</p>

      <div className="mt-6 mb-6">
        <span className="text-5xl font-bold text-gray-900">${plan.price}</span>
        <span className="text-gray-600">/month</span>
      </div>

      <button
        onClick={handleUpgrade}
        disabled={loading}
        className={`w-full rounded-lg py-3 font-semibold mb-8 ${
          plan.popular
            ? 'bg-blue-600 text-white hover:bg-blue-700'
            : 'border border-gray-300 text-gray-900 hover:bg-gray-50'
        } disabled:opacity-50`}
      >
        {loading ? 'Processing...' : plan.cta}
      </button>

      <ul className="space-y-4 flex-1">
        {plan.features.map((feature) => (
          <li key={feature} className="flex items-start gap-3">
            <span className="text-green-600 font-bold">✓</span>
            <span className="text-gray-700">{feature}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}
