'use client';

import { useEffect, useState } from 'react';
import { signOut, useSession } from 'next-auth/react';
import { Menu, LogOut, User } from 'lucide-react';
import { Button } from '@/components/ui/Button';

interface TopNavProps {
  toggleSidebar: () => void;
}

interface UserData {
  plan: string;
  subscriptionStatus: string;
}

export default function TopNav({ toggleSidebar }: TopNavProps) {
  const { data: session } = useSession();
  const [user, setUser] = useState<UserData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const res = await fetch('/api/user');
        if (res.ok) {
          const data = await res.json();
          setUser(data);
        }
      } catch (error) {
        console.error('Failed to fetch user:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchUser();
  }, []);

  const planColor = {
    FREE: 'bg-gray-100 text-gray-800',
    PRO: 'bg-blue-100 text-blue-800',
    BUSINESS: 'bg-purple-100 text-purple-800',
  }[user?.plan as string] || 'bg-gray-100 text-gray-800';

  return (
    <header className="bg-white border-b border-gray-200 px-6 py-4">
      <div className="flex items-center justify-between">
        <button
          onClick={toggleSidebar}
          className="md:hidden p-2 hover:bg-gray-100 rounded-lg"
        >
          <Menu className="w-6 h-6" />
        </button>

        <div className="flex-1" />

        <div className="flex items-center gap-6">
          {!loading && user && (
            <div className={`px-3 py-1 rounded-full text-sm font-medium ${planColor}`}>
              {user.plan} Plan
            </div>
          )}

          <div className="flex items-center gap-4">
            <div>
              <p className="text-sm font-medium text-gray-900">{session?.user?.name}</p>
              <p className="text-xs text-gray-500">{session?.user?.email}</p>
            </div>

            <button
              onClick={() => signOut({ redirect: true, callbackUrl: '/' })}
              className="p-2 hover:bg-gray-100 rounded-lg text-gray-600"
              title="Sign Out"
            >
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}
