import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';
import { withPlan } from '@/lib/middleware';

export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    // Check if user has automation access (PRO or BUSINESS)
    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      select: { plan: true },
    });

    if (!user || (user.plan !== 'PRO' && user.plan !== 'BUSINESS')) {
      return NextResponse.json(
        { error: 'Automations require PRO or BUSINESS plan' },
        { status: 403 }
      );
    }

    const automations = await prisma.automation.findMany({
      where: { userId: session.user.id },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json(automations);
  } catch (error) {
    console.error('Get automations error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch automations' },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    // Check if user has automation access
    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      select: { plan: true, automationCount: true },
    });

    if (!user || (user.plan !== 'PRO' && user.plan !== 'BUSINESS')) {
      return NextResponse.json(
        { error: 'Automations require PRO or BUSINESS plan' },
        { status: 403 }
      );
    }

    // PRO plan has max 5 automations, BUSINESS unlimited
    if (user.plan === 'PRO' && user.automationCount >= 5) {
      return NextResponse.json(
        { error: 'Automation limit reached for PRO plan' },
        { status: 429 }
      );
    }

    const { name, description, trigger, action, condition } = await req.json();

    if (!name || !trigger || !action) {
      return NextResponse.json(
        { error: 'Name, trigger, and action are required' },
        { status: 400 }
      );
    }

    const automation = await prisma.automation.create({
      data: {
        userId: session.user.id,
        name,
        description,
        trigger,
        action,
        condition: condition ? JSON.stringify(condition) : null,
      },
    });

    // Increment automation count
    await prisma.user.update({
      where: { id: session.user.id },
      data: { automationCount: { increment: 1 } },
    });

    return NextResponse.json(automation, { status: 201 });
  } catch (error) {
    console.error('Create automation error:', error);
    return NextResponse.json(
      { error: 'Failed to create automation' },
      { status: 500 }
    );
  }
}
