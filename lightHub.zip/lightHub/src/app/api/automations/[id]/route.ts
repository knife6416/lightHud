import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export async function GET(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const automation = await prisma.automation.findUnique({
      where: { id: params.id },
    });

    if (!automation || automation.userId !== session.user.id) {
      return NextResponse.json(
        { error: 'Automation not found' },
        { status: 404 }
      );
    }

    return NextResponse.json(automation);
  } catch (error) {
    console.error('Get automation error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch automation' },
      { status: 500 }
    );
  }
}

export async function PATCH(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const automation = await prisma.automation.findUnique({
      where: { id: params.id },
    });

    if (!automation || automation.userId !== session.user.id) {
      return NextResponse.json(
        { error: 'Automation not found' },
        { status: 404 }
      );
    }

    const { name, description, trigger, action, condition, isEnabled } =
      await req.json();

    const updated = await prisma.automation.update({
      where: { id: params.id },
      data: {
        ...(name && { name }),
        ...(description !== undefined && { description }),
        ...(trigger && { trigger }),
        ...(action && { action }),
        ...(condition && { condition: JSON.stringify(condition) }),
        ...(isEnabled !== undefined && { isEnabled }),
      },
    });

    return NextResponse.json(updated);
  } catch (error) {
    console.error('Update automation error:', error);
    return NextResponse.json(
      { error: 'Failed to update automation' },
      { status: 500 }
    );
  }
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const automation = await prisma.automation.findUnique({
      where: { id: params.id },
    });

    if (!automation || automation.userId !== session.user.id) {
      return NextResponse.json(
        { error: 'Automation not found' },
        { status: 404 }
      );
    }

    await prisma.automation.delete({
      where: { id: params.id },
    });

    // Decrement automation count
    await prisma.user.update({
      where: { id: session.user.id },
      data: { automationCount: { decrement: 1 } },
    });

    return NextResponse.json({ message: 'Automation deleted' });
  } catch (error) {
    console.error('Delete automation error:', error);
    return NextResponse.json(
      { error: 'Failed to delete automation' },
      { status: 500 }
    );
  }
}
