import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';
import { checkUsageQuota } from '@/lib/middleware';

export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(req.url);
    const feature = searchParams.get('feature') as
      | 'aiRequests'
      | 'tasksPerMonth'
      | 'automations'
      | null;

    if (!feature || !['aiRequests', 'tasksPerMonth', 'automations'].includes(feature)) {
      return NextResponse.json(
        { error: 'Invalid feature parameter' },
        { status: 400 }
      );
    }

    const quota = await checkUsageQuota(session.user.id, feature);

    return NextResponse.json(quota);
  } catch (error) {
    console.error('Usage check error:', error);
    return NextResponse.json(
      { error: 'Failed to check usage' },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const { feature } = await req.json();

    if (!feature || !['aiRequests', 'tasksPerMonth', 'automations'].includes(feature)) {
      return NextResponse.json(
        { error: 'Invalid feature parameter' },
        { status: 400 }
      );
    }

    const quota = await checkUsageQuota(session.user.id, feature);

    return NextResponse.json(quota);
  } catch (error) {
    console.error('Usage check error:', error);
    return NextResponse.json(
      { error: 'Failed to check usage' },
      { status: 500 }
    );
  }
}
