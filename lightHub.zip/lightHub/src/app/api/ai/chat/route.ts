import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';
import { checkUsageQuota } from '@/lib/middleware';
import { prisma } from '@/lib/db';

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    // Check usage quota
    const quota = await checkUsageQuota(session.user.id, 'aiRequests');
    if (!quota.allowed) {
      return NextResponse.json(
        {
          error: 'AI request limit reached',
          current: quota.current,
          limit: quota.limit,
          plan: quota.plan,
        },
        { status: 429 }
      );
    }

    const { taskId, prompt, taskTitle, taskDescription } = await req.json();

    if (!prompt && !taskId) {
      return NextResponse.json(
        { error: 'Prompt or taskId is required' },
        { status: 400 }
      );
    }

    let aiResponse: string;

    // For MVP, we'll simulate AI responses
    // In production, integrate with OpenAI, Claude, or similar
    if (taskId) {
      const task = await prisma.task.findUnique({
        where: { id: taskId },
      });

      if (!task || task.userId !== session.user.id) {
        return NextResponse.json(
          { error: 'Task not found' },
          { status: 404 }
        );
      }

      // Simulate AI summary generation
      aiResponse = `Summary for "${task.title}": This task requires focus on the core objectives. Break it down into smaller subtasks for better progress tracking. Estimated completion: 2-3 hours. Recommended priority: ${task.priority || 'medium'}.`;
    } else {
      // Free-form AI assistant response
      aiResponse = `AI Assistant: ${prompt.substring(0, 50)}... Understanding your request. Key insights: 1) Break down complex tasks, 2) Use time-blocking techniques, 3) Review daily progress. This is a simulated response - connect OpenAI API for real AI responses.`;
    }

    // Increment usage
    await prisma.user.update({
      where: { id: session.user.id },
      data: { usageCount: { increment: 1 } },
    });

    return NextResponse.json({
      response: aiResponse,
      taskId,
      usageUpdated: true,
    });
  } catch (error) {
    console.error('AI request error:', error);
    return NextResponse.json(
      { error: 'Failed to process AI request' },
      { status: 500 }
    );
  }
}
