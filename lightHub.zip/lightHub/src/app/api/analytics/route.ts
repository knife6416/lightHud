import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    // Get analytics for last 30 days
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

    const analytics = await prisma.analytics.findMany({
      where: {
        userId: session.user.id,
        date: {
          gte: thirtyDaysAgo,
        },
      },
      orderBy: { date: 'desc' },
    });

    // Get summary stats
    const totalTasksCompleted = analytics.reduce((sum, a) => sum + a.tasksCompleted, 0);
    const totalAiRequests = analytics.reduce((sum, a) => sum + a.aiRequests, 0);
    const totalFocusTime = analytics.reduce((sum, a) => sum + a.focusTime, 0);
    const totalAutomationsTriggered = analytics.reduce((sum, a) => sum + a.automationsTriggered, 0);

    return NextResponse.json({
      analytics,
      summary: {
        totalTasksCompleted,
        totalAiRequests,
        totalFocusTime,
        totalAutomationsTriggered,
        daysTracked: analytics.length,
      },
    });
  } catch (error) {
    console.error('Analytics error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch analytics' },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const {
      tasksCreated,
      tasksCompleted,
      aiRequests,
      automationsTriggered,
      focusTime,
    } = await req.json();

    const analytics = await prisma.analytics.create({
      data: {
        userId: session.user.id,
        tasksCreated: tasksCreated || 0,
        tasksCompleted: tasksCompleted || 0,
        aiRequests: aiRequests || 0,
        automationsTriggered: automationsTriggered || 0,
        focusTime: focusTime || 0,
      },
    });

    return NextResponse.json(analytics, { status: 201 });
  } catch (error) {
    console.error('Create analytics error:', error);
    return NextResponse.json(
      { error: 'Failed to create analytics' },
      { status: 500 }
    );
  }
}
