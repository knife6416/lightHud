import Link from 'next/link';
import { Button } from '@/components/ui/Button';
import { Check, Zap } from 'lucide-react';

const PLANS = [
  {
    name: 'Free',
    price: 0,
    description: 'Perfect for getting started',
    features: [
      'Limited tasks (50/month)',
      '20 AI requests per month',
      'Basic dashboard',
      'No automations',
      'Watermark in exports',
    ],
    cta: 'Get Started',
    href: '/signup',
    featured: false,
  },
  {
    name: 'Pro',
    price: 19,
    description: 'Best for individuals and small teams',
    features: [
      'Unlimited tasks',
      '500 AI requests per month',
      'Automations enabled',
      'Focus mode',
      'Analytics',
      'Priority AI response',
    ],
    cta: 'Upgrade to Pro',
    href: '/dashboard',
    featured: true,
  },
  {
    name: 'Business',
    price: 49,
    description: 'For organizations and teams',
    features: [
      'Unlimited AI requests',
      'Team collaboration',
      'Shared projects',
      'Admin dashboard',
      'Advanced analytics',
      'API access',
      'Priority support',
    ],
    cta: 'Upgrade to Business',
    href: '/dashboard',
    featured: false,
  },
];

export default function PricingPage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="flex items-center justify-between px-6 py-4 max-w-7xl mx-auto border-b">
        <Link href="/" className="flex items-center gap-2">
          <Zap className="w-8 h-8 text-primary-600" />
          <span className="text-2xl font-bold text-primary-900">lightHub</span>
        </Link>
        <div className="flex gap-4">
          <Link href="/login">
            <Button variant="outline">Sign In</Button>
          </Link>
          <Link href="/signup">
            <Button>Get Started</Button>
          </Link>
        </div>
      </nav>

      {/* Pricing Section */}
      <section className="py-20 px-6">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-5xl font-bold text-center mb-4">Simple, Transparent Pricing</h1>
          <p className="text-center text-gray-600 text-lg mb-12">
            Choose the perfect plan for your needs. Always flexible to scale.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {PLANS.map((plan) => (
              <PricingCard key={plan.name} plan={plan} />
            ))}
          </div>

          <div className="mt-20 p-8 bg-primary-50 rounded-lg border border-primary-200">
            <h2 className="text-2xl font-bold mb-4">All plans include:</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[
                'Secure cloud storage',
                'Team collaboration',
                'Regular backups',
                'Email support',
              ].map((feature) => (
                <div key={feature} className="flex items-center gap-2">
                  <Check className="w-5 h-5 text-green-500" />
                  <span>{feature}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-20 px-6 bg-gray-50">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-12">Frequently Asked Questions</h2>
          <div className="space-y-6">
            <FAQItem
              question="Can I change my plan anytime?"
              answer="Yes, you can upgrade or downgrade your plan at any time. Changes take effect immediately."
            />
            <FAQItem
              question="Is there a free trial?"
              answer="Yes! Start with our Free plan with no credit card required. Upgrade anytime."
            />
            <FAQItem
              question="What payment methods do you accept?"
              answer="We accept all major credit cards, debit cards, and digital payment methods through Stripe."
            />
            <FAQItem
              question="Can I get a refund?"
              answer="We offer a 7-day money-back guarantee for new subscriptions. Contact support for assistance."
            />
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <p>&copy; 2024 lightHub. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

function PricingCard({ plan }: { plan: (typeof PLANS)[0] }) {
  return (
    <div
      className={`rounded-lg border transition ${
        plan.featured
          ? 'border-primary-600 shadow-lg scale-105'
          : 'border-gray-200 hover:border-gray-300'
      } p-8`}
    >
      {plan.featured && (
        <div className="bg-primary-600 text-white text-sm font-semibold py-1 px-3 rounded-full inline-block mb-4">
          Most Popular
        </div>
      )}
      <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
      <p className="text-gray-600 mb-6">{plan.description}</p>

      <div className="mb-6">
        <span className="text-5xl font-bold">${plan.price}</span>
        <span className="text-gray-600">/month</span>
      </div>

      <Link href={plan.href}>
        <Button
          className="w-full mb-8"
          variant={plan.featured ? 'default' : 'outline'}
        >
          {plan.cta}
        </Button>
      </Link>

      <div className="space-y-4">
        {plan.features.map((feature) => (
          <div key={feature} className="flex items-start">
            <Check className="w-5 h-5 text-green-500 mr-3 flex-shrink-0 mt-0.5" />
            <span className="text-gray-700">{feature}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function FAQItem({
  question,
  answer,
}: {
  question: string;
  answer: string;
}) {
  return (
    <div className="bg-white p-6 rounded-lg border border-gray-200">
      <h3 className="text-lg font-semibold mb-2">{question}</h3>
      <p className="text-gray-600">{answer}</p>
    </div>
  );
}
