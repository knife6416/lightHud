import type { Metadata } from 'next';
import './globals.css';
import { Toaster } from 'react-hot-toast';

export const metadata: Metadata = {
  title: 'lightHub - AI SaaS Productivity Platform',
  description: 'Manage tasks, automate workflows, and leverage AI assistance with lightHub',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="bg-white dark:bg-slate-950">
        {children}
        <Toaster position="top-right" />
      </body>
    </html>
  );
}
