'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import Link from 'next/link';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import {
  ArrowRight,
  CheckCircle2,
  Clock,
  AlertCircle,
  Zap,
  TrendingUp,
} from 'lucide-react';

interface DashboardStats {
  tasksCompleted: number;
  aiRequests: number;
  automations: number;
  plan: string;
  usageCount: number;
  taskCreatedCount: number;
}

export default function DashboardPage() {
  const { data: session } = useSession();
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const res = await fetch('/api/user');
        if (res.ok) {
          const data = await res.json();
          setStats(data);
        }
      } catch (error) {
        console.error('Failed to fetch stats:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-primary-600"></div>
      </div>
    );
  }

  return (
    <div>
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Welcome back, {session?.user?.name}!</h1>
        <p className="text-gray-600">Here's your productivity overview</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard
          title="Tasks Completed"
          value={stats?.taskCreatedCount || 0}
          icon={<CheckCircle2 className="w-6 h-6 text-green-600" />}
          trend="+12% this month"
        />
        <StatCard
          title="AI Requests"
          value={stats?.usageCount || 0}
          icon={<Zap className="w-6 h-6 text-yellow-600" />}
          trend="Monthly quota"
        />
        <StatCard
          title="Active Automations"
          value="3"
          icon={<TrendingUp className="w-6 h-6 text-blue-600" />}
          trend="Running smoothly"
        />
        <StatCard
          title="Current Plan"
          value={stats?.plan || 'FREE'}
          icon={<AlertCircle className="w-6 h-6 text-purple-600" />}
          trend="View pricing"
          href="/dashboard/billing"
        />
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Quick Actions */}
        <Card className="lg:col-span-2">
          <div className="p-6">
            <h2 className="text-xl font-bold mb-6">Quick Actions</h2>
            <div className="space-y-3">
              <ActionButton
                icon={<CheckCircle2 className="w-5 h-5" />}
                label="Create New Task"
                href="/dashboard/tasks"
              />
              <ActionButton
                icon={<Zap className="w-5 h-5" />}
                label="Use AI Assistant"
                href="/dashboard/ai"
              />
              <ActionButton
                icon={<TrendingUp className="w-5 h-5" />}
                label="View Analytics"
                href="/dashboard/analytics"
              />
              {stats?.plan === 'FREE' && (
                <ActionButton
                  icon={<AlertCircle className="w-5 h-5" />}
                  label="Upgrade to Pro"
                  href="/dashboard/billing"
                  variant="highlight"
                />
              )}
            </div>
          </div>
        </Card>

        {/* Usage Summary */}
        <Card>
          <div className="p-6">
            <h2 className="text-xl font-bold mb-6">Usage Summary</h2>
            <div className="space-y-4">
              <UsageBar
                label="AI Requests"
                current={stats?.usageCount || 0}
                max={stats?.plan === 'FREE' ? 20 : stats?.plan === 'PRO' ? 500 : -1}
              />
              <UsageBar
                label="Tasks Created"
                current={stats?.taskCreatedCount || 0}
                max={stats?.plan === 'FREE' ? 50 : -1}
              />
            </div>
          </div>
        </Card>
      </div>

      {/* Upgrade Banner */}
      {stats?.plan === 'FREE' && (
        <div className="mt-8 bg-gradient-to-r from-blue-100 to-purple-100 border border-blue-200 rounded-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Ready to unlock more?</h3>
              <p className="text-gray-700">
                Upgrade to Pro for unlimited tasks, 500 AI requests, and automations.
              </p>
            </div>
            <Link href="/dashboard/billing">
              <Button>Upgrade Now <ArrowRight className="w-4 h-4 ml-2" /></Button>
            </Link>
          </div>
        </div>
      )}
    </div>
  );
}

function StatCard({
  title,
  value,
  icon,
  trend,
  href,
}: {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  trend: string;
  href?: string;
}) {
  const content = (
    <Card>
      <div className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div>
            <p className="text-gray-600 text-sm">{title}</p>
            <p className="text-3xl font-bold text-gray-900 mt-2">{value}</p>
          </div>
          {icon}
        </div>
        <p className="text-xs text-gray-500">{trend}</p>
      </div>
    </Card>
  );

  if (href) {
    return <Link href={href}>{content}</Link>;
  }

  return content;
}

function ActionButton({
  icon,
  label,
  href,
  variant = 'default',
}: {
  icon: React.ReactNode;
  label: string;
  href: string;
  variant?: 'default' | 'highlight';
}) {
  return (
    <Link href={href}>
      <div className={`flex items-center gap-3 p-4 rounded-lg cursor-pointer transition ${
        variant === 'highlight'
          ? 'bg-primary-50 border border-primary-600 hover:bg-primary-100'
          : 'bg-gray-50 border border-gray-200 hover:bg-gray-100'
      }`}>
        <div className={variant === 'highlight' ? 'text-primary-600' : 'text-gray-600'}>
          {icon}
        </div>
        <div className="flex-1">
          <p className={`font-medium ${variant === 'highlight' ? 'text-primary-900' : 'text-gray-900'}`}>
            {label}
          </p>
        </div>
        <ArrowRight className={`w-5 h-5 ${variant === 'highlight' ? 'text-primary-600' : 'text-gray-400'}`} />
      </div>
    </Link>
  );
}

function UsageBar({
  label,
  current,
  max,
}: {
  label: string;
  current: number;
  max: number;
}) {
  const percentage = max === -1 ? 0 : (current / max) * 100;

  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <p className="text-sm font-medium text-gray-900">{label}</p>
        <p className="text-sm text-gray-600">
          {current}
          {max !== -1 ? `/${max}` : ' unlimited'}
        </p>
      </div>
      {max !== -1 && (
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div
            className="bg-primary-600 h-2 rounded-full transition-all"
            style={{ width: `${Math.min(percentage, 100)}%` }}
          />
        </div>
      )}
    </div>
  );
}
