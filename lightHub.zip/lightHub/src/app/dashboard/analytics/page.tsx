'use client';

import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { BarChart3 } from 'lucide-react';

export default function AnalyticsPage() {
  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Analytics</h1>
        <p className="text-gray-600">Track your productivity and performance metrics</p>
      </div>

      <Card className="p-8 text-center">
        <BarChart3 className="w-16 h-16 text-green-600 mx-auto mb-4" />
        <h2 className="text-2xl font-bold mb-3">Analytics Dashboard Coming Soon</h2>
        <p className="text-gray-600 mb-6">
          Get insights into your productivity:
        </p>
        <ul className="text-gray-600 space-y-2 max-w-md mx-auto mb-8">
          <li>📊 Task completion trends</li>
          <li>⏱️ Focus time tracking</li>
          <li>📈 Performance metrics</li>
        </ul>
        <Button>Explore Features</Button>
      </Card>
    </div>
  );
}
