'use client';

import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { CheckSquare } from 'lucide-react';

export default function AutomationsPage() {
  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Automations</h1>
        <p className="text-gray-600">Set up workflows and automate your tasks</p>
      </div>

      <Card className="p-8 text-center">
        <CheckSquare className="w-16 h-16 text-blue-600 mx-auto mb-4" />
        <h2 className="text-2xl font-bold mb-3">Automations Coming Soon</h2>
        <p className="text-gray-600 mb-6">
          Create powerful automations to streamline your workflow:
        </p>
        <ul className="text-gray-600 space-y-2 max-w-md mx-auto mb-8">
          <li>🔄 Trigger-based automation</li>
          <li>📧 Email notifications</li>
          <li>⏰ Schedule workflows</li>
        </ul>
        <Button>Learn More</Button>
      </Card>
    </div>
  );
}
