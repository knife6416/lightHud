'use client';

import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Zap } from 'lucide-react';

export default function AIAssistantPage() {
  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">AI Assistant</h1>
        <p className="text-gray-600">Get AI-powered suggestions and task summaries</p>
      </div>

      <Card className="p-8 text-center">
        <Zap className="w-16 h-16 text-yellow-600 mx-auto mb-4" />
        <h2 className="text-2xl font-bold mb-3">Coming Soon</h2>
        <p className="text-gray-600 mb-6">
          Our AI assistant is currently in development. You'll be able to:
        </p>
        <ul className="text-gray-600 space-y-2 max-w-md mx-auto mb-8">
          <li>✨ Get intelligent task summaries</li>
          <li>💡 Receive AI-powered suggestions</li>
          <li>⚡ Transform your workflow with AI</li>
        </ul>
        <Button>Get Notified</Button>
      </Card>
    </div>
  );
}
