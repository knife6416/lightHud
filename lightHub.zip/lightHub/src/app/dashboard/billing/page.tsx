'use client';

import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Check, AlertCircle, CreditCard } from 'lucide-react';
import toast from 'react-hot-toast';
import { useRouter } from 'next/navigation';

interface UserBilling {
  plan: string;
  subscriptionStatus: string;
  currentPeriodEnd: string | null;
  stripeCustomerId: string | null;
}

const PLANS = {
  FREE: {
    name: 'Free',
    price: 0,
    features: [
      'Limited tasks (50/month)',
      '20 AI requests per month',
      'Basic dashboard',
      'No automations',
      'Watermark in exports',
    ],
  },
  PRO: {
    name: 'Pro',
    price: 19,
    features: [
      'Unlimited tasks',
      '500 AI requests per month',
      'Automations enabled',
      'Focus mode',
      'Analytics',
      'Priority AI response',
    ],
  },
  BUSINESS: {
    name: 'Business',
    price: 49,
    features: [
      'Unlimited AI requests',
      'Team collaboration',
      'Shared projects',
      'Admin dashboard',
      'Advanced analytics',
      'API access',
      'Priority support',
    ],
  },
};

export default function BillingPage() {
  const [userBilling, setUserBilling] = useState<UserBilling | null>(null);
  const [loading, setLoading] = useState(true);
  const [upgrading, setUpgrading] = useState<string | null>(null);
  const router = useRouter();

  useEffect(() => {
    const fetchBilling = async () => {
      try {
        const res = await fetch('/api/user');
        if (res.ok) {
          const data = await res.json();
          setUserBilling(data);
        }
      } catch (error) {
        toast.error('Failed to load billing information');
      } finally {
        setLoading(false);
      }
    };

    fetchBilling();
  }, []);

  const handleUpgrade = async (plan: string) => {
    if (userBilling?.plan === plan) {
      return;
    }

    setUpgrading(plan);
    try {
      const res = await fetch('/api/stripe/create-checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ plan: plan.toLowerCase() }),
      });

      if (res.ok) {
        const { url } = await res.json();
        window.location.href = url;
      } else {
        toast.error('Failed to start checkout');
      }
    } catch (error) {
      toast.error('Failed to upgrade plan');
    } finally {
      setUpgrading(null);
    }
  };

  const handleManageBilling = async () => {
    try {
      const res = await fetch('/api/stripe/create-portal', { method: 'POST' });

      if (res.ok) {
        const { url } = await res.json();
        window.location.href = url;
      } else {
        toast.error('Failed to access billing portal');
      }
    } catch (error) {
      toast.error('Failed to access billing portal');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-primary-600"></div>
      </div>
    );
  }

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Billing</h1>
        <p className="text-gray-600">Manage your subscription and payment methods</p>
      </div>

      {/* Current Plan */}
      {userBilling?.plan !== 'FREE' && (
        <Card className="mb-8 border-primary-600 bg-primary-50">
          <div className="p-6">
            <div className="flex items-start justify-between">
              <div>
                <h2 className="text-2xl font-bold text-gray-900 mb-2">
                  {PLANS[userBilling?.plan as keyof typeof PLANS]?.name} Plan Active
                </h2>
                {userBilling?.currentPeriodEnd && (
                  <p className="text-gray-600">
                    Your subscription renews on{' '}
                    {new Date(userBilling.currentPeriodEnd).toLocaleDateString()}
                  </p>
                )}
                <p className="text-sm text-gray-500 mt-2">
                  Status: <span className="font-medium text-green-600">Active</span>
                </p>
              </div>
              <Button onClick={handleManageBilling} variant="outline">
                <CreditCard className="w-5 h-5 mr-2" />
                Manage Billing
              </Button>
            </div>
          </div>
        </Card>
      )}

      {/* Pricing Cards */}
      <div className="mb-8">
        <h2 className="text-2xl font-bold mb-6">Choose Your Plan</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {Object.entries(PLANS).map(([key, plan]) => {
            const isCurrentPlan = userBilling?.plan === key;

            return (
              <Card key={key} className={`relative ${isCurrentPlan ? 'border-primary-600 shadow-lg' : ''}`}>
                {isCurrentPlan && (
                  <div className="absolute -top-3 left-4 bg-primary-600 text-white px-3 py-1 rounded-full text-sm font-medium">
                    Current Plan
                  </div>
                )}

                <div className={`p-6 ${isCurrentPlan ? 'pt-10' : ''}`}>
                  <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
                  <div className="mb-6">
                    <span className="text-4xl font-bold">${plan.price}</span>
                    <span className="text-gray-600">/month</span>
                  </div>

                  {isCurrentPlan ? (
                    <Button disabled className="w-full mb-6">
                      Current Plan
                    </Button>
                  ) : (
                    <Button
                      onClick={() => handleUpgrade(key)}
                      disabled={upgrading === key}
                      className="w-full mb-6"
                      variant={key === 'PRO' ? 'default' : 'outline'}
                    >
                      {upgrading === key ? 'Processing...' : `Upgrade to ${plan.name}`}
                    </Button>
                  )}

                  <div className="space-y-3">
                    {plan.features.map((feature) => (
                      <div key={feature} className="flex items-start gap-3">
                        <Check className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                        <span className="text-gray-700">{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      </div>

      {/* Billing Information */}
      {userBilling?.stripeCustomerId && (
        <Card>
          <div className="p-6">
            <div className="flex items-center gap-2 mb-4">
              <AlertCircle className="w-5 h-5 text-blue-600" />
              <h3 className="text-lg font-bold">Billing Portal</h3>
            </div>
            <p className="text-gray-600 mb-4">
              Access your Stripe billing portal to manage payment methods, view invoices, and update your billing information.
            </p>
            <Button onClick={handleManageBilling} variant="outline">
              Go to Billing Portal
            </Button>
          </div>
        </Card>
      )}
    </div>
  );
}
